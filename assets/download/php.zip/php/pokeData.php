<?php 
  require "display.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PokeData</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
  <?php 
    if(isset($_GET["type"]))
    {
  ?>
      <h1>PokeData</h1>
      <?php DisplayTitle(true) ?>
      <p><em>*Les pokémons sont ajoutés selon un ordre.</em></p>
      <h3>PokeData - Paramétrage :</h3>
      <button class="button" onclick=window.location="index.php">Retour</button>
      <h3>PokeData - Description du type :</h3>
      <h4>Les attaques</h4>
      <?php DisplayPagePokemonTypeAttacks(); ?>
      <h3>PokeData - Listes :</h3>
      <?php DisplayPagePokemonType(); ?>
  <?php 
    }
    else
    {
  ?>  
      <h1>PokeData</h1>
      <h2>PokeData - Pokémons - Type :</h2>
      <p><em>*Les pokémons sont ajoutés selon leur arrivé.</em></p>
      <h3>PokeData - Paramétrage :</h3>
      <?php DisplayButtons(GetDataTypesFromBDD("SELECT id,name,details FROM `types` ORDER BY `name` ASC")); ?>
      <h3>PokeData - Accueil :</h3>
      <button class="button" onclick=window.location="index.php">Retour à l'accueil</button>
  <?php 
    }
  ?>
</body>
</html>