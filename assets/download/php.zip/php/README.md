# POKÉMON PHP - Christopher Rieffel

## Objectif 
Création d'un site web permettant d'afficher divers pokémons provenants d'une BDD.

## Tâches 
* Créer un fichier README 
* Afficher une liste des pokémons avec leurs informations.
* Afficher une liste des pokémons en fonction de leur type avec leurs informations 
* Permettre l'ajout de pokémon dans la BDD à l'aide d'un formulaire (et l'afficher)
* Permettre de supprimer le/les pokémons de la BDD.
* Afficher les attaques en fonction de leur type.

## Progression
* Création du projet : 25/05/2021
* Tâche 1 - (TERMINER) : 25/05/2021 - 28/05/2021
* Tâche 2 - (TERMINER) : 28/05/2021 - 02/06/2021
* Tâche 3 - (TERMINER) : 02/06/2021 - 03/06/2021
* Tâche 4 - (TERMINER) : 03/06/2021 - 03/06/2021
* Tâche 5 - (TERMINER) : 03/06/2021 - 03/06/2021
* Tâche 6 - (TERMINER) : 03/06/2021 - 07/06/2021
* Tâche 7 - (TERMINER) : 07/06/2021 - 07/06/2021
* Tâche 8 - (TERMINER) : 07/06/2021 - 07/06/2021

## Information
* Site réalisé en php et en css 
* La base de donnée est en SQL.