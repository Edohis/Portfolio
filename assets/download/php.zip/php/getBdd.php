<!-- FUNCTION QUI PERMET DE CE CONNECTER À LA BBD -->

<?php 
  function getBDD()
  {
    $bdd = new PDO('mysql:host=localhost;dbname=assesment', 'bourgeoisassesment', 'pass');
    return $bdd;
  }
?>