<?php 
  require "display.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PokeData</title>
    <link type="text/css" rel="stylesheet" href="style.css" />
</head>
<body>
    <h1>PokeData</h1>
    <h2>PokeData - Pokémons :</h2>
    <p><em>*Les pokémons sont ajoutés selon un ordre.</em></p>
    <h3>PokeData - Paramétrage :</h3>
    <?php DisplayButtons(GetDataTypesFromBDD("SELECT id,name,details FROM `types` ORDER BY `name` ASC")); ?>
    <h3>PokeData - Ajouter un pokémon :</h3>
    <?php PokeDataCheck(); ?> 
    <form class="FormPoke" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <label for="pnumber">Numéro du pokémon :</label>
      <input type="number" id="pnumber" name="pokeId" value="" placeholder="Saisissez un numéro" required>
      <br />
      <label for="pname">Nom du pokémon :</label>
      <input type="text" id="pname" name="pokeName" value="" placeholder="Saisissez un nom" required>
      <?php 
        global $pokeNameError;
        if($pokeNameError != '')
        {
          ?>
          <br />
          <span class="error"><?php global $pokeNameError; echo $pokeNameError;?></span>
      <?php
        }
      ?> 
      <br />
      <label for="ptype">Type du pokémon :</label><br />
      <input type="radio" id="ptype" name="pokeType" value="1">Combat
      <input type="radio" id="ptype" name="pokeType" value="2">Dragon
      <input type="radio" id="ptype" name="pokeType" value="4">Eau
      <input type="radio" id="ptype" name="pokeType" value="7">Fée
      <input type="radio" id="ptype" name="pokeType" value="5">Insecte
      <input type="radio" id="ptype" name="pokeType" value="3">Plante
      <input type="radio" id="ptype" name="pokeType" value="6">Psy
      <br />
      <label for="pimage">Lien de l'image :</label>
      <input type="url" id="pimage" name="pokeUrl" value="" placeholder="Saisissez l'adresse url de l'image du pokémon" required>
      <br />
      <input type="submit" name="submit" value="Envoyer">
    </form>
    <h4>Votre pokémon ajouté :</h4>
    <?php 
    global $pokeNumber;
    global $pokeName;
    global $pokeType;
    global $pokeImage; 

    if($pokeNumber == "" && $pokeName == '' && $pokeType == '' && $pokeImage == '')
    {
      echo "<p>Aucun pokémon ajouté !</p>";
    }
    else
    {
      DisplayLastPokeAddByUser($GLOBALS["pokeNumber"],$GLOBALS["pokeName"],$GLOBALS["pokeType"],$GLOBALS["pokeImage"]); 
    }
    ?>
    <h3>PokeData - Listes :</h3>
    <?php DisplayPokemon(GetDataPokeFromBDD("SELECT *, pokemons.name as fullName FROM pokemons INNER JOIN types ON pokemons.type = types.id ORDER BY `pokemons`.`type` ASC")); ?>
</body>
</html>