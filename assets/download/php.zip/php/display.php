<?php 
    require "getBdd.php"
?>

<link type="text/css" rel="stylesheet" href="style.css" />

<!-- FONCTION QUI PERMET DE SUPPRIMER UN POKEMON --> 
<?php
    if(!empty($_POST['pokesId'])) 
    {
        $data = getBDD();
        $sql = 'DELETE FROM pokemons WHERE pokemons.number ="'.$_POST['pokesId'].'"';
        $result = $data->query($sql);
        header("Location: index.php");
    }
?>

<!-- FONCTION QUI PERMET D'AFFICHER TOUS LES POKEMONS SOUS LA FORME D'UN TABLEAU -->  
<?php 
    function DisplayPokeData($Data)
    {
?>
        <table cellspacing="5" cellpadding="5" width="100%">
            <thead>
                <tr>
                    <th class="cell">Numéro</th>
                    <th class="cell">Nom</th>
                    <th class="cell">Type</th>
                    <th class="cell">Image</th>
                    <th class="cell">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
                for($i=0; $i < 1 ; $i++)
                {
            ?>
            <tr>
                <td class="cell"><?php echo $Data['number']; ?></td>
                <td class="cell"><?php echo $Data['fullName']; ?></td>
                <td class="cell"><?php echo $Data['name']; ?></td>
                <td class="cell"><img class="image" src="<?php echo $Data['image']; ?>" alt=""/></td>
                <td class='cell'>
                    <form class="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                        <input type="hidden" id="pokeId" name="pokesId" value="<?php echo $Data['number'];?>">
                        <input type='submit' value='Retirer ce pokémon'>
                    </form>
                </td>
            </tr>
            <?php 
                } 
            ?>
            </tbody>
        </table>
<?php 
    } 
?>

<!-- FONCTION QUI PERMET D'AFFICHER UN POKEMON -->
<?php 
    function DisplayPokemon($PokeDataList)
    {
        foreach($PokeDataList as $Data)
        {
            DisplayPokeData($Data);
        }
    }
?>

<!-- FONCTION QUI PERMET DE RECUPERER LES DONNEES DE POKEMONS DANS LA BDD -->
<?php 
    function GetDataPokeFromBDD($criteria)
    {
        $data = getBDD();
        $sql = $criteria;
        $result = $data->query($sql);
        $PokeDataList = [];
        foreach($result as $PokeData)
        {
            $PokeDataGet['number'] = $PokeData['number'];
            $PokeDataGet['fullName'] = $PokeData['fullName'];
            $PokeDataGet['name'] = $PokeData['name'];
            $PokeDataGet['image'] = $PokeData['image'];

            array_push($PokeDataList, $PokeDataGet);
       }
        return $PokeDataList;
    }
?>

<!-- FONCTION QUI PERMET DE RECUPERER LES DONNEES DE TYPE DANS LA BDD -->
<?php 
    function GetDataTypesFromBDD($criteria)
    {
        $data = getBDD();
        $sql = $criteria;
        $result = $data->query($sql);
        $TypeDataList = [];
        foreach($result as $TypeData)
        {
            $TypeDataGet['id'] = $TypeData['id'];
            $TypeDataGet['name'] = $TypeData['name'];
            $TypeDataGet['details'] = $TypeData['details'];

            array_push($TypeDataList, $TypeDataGet);
       }
        return $TypeDataList;
    }
?>

<!-- FONCTION QUI PERMET DE RECUPERER LES DONNEES DE TYPE D'ATTATQUE DANS LA BDD -->
<?php 
    function GetDataAttacksFromBDD($ID)
    {
        $data = getBDD();
        $sql = "SELECT * FROM attacks INNER JOIN types_attacks ON attacks.ID = types_attacks.attack_ID ORDER BY `attacks`.`ID` ASC"; //$criteria;
        $result = $data->query($sql);
        $AttackDataList = [];
        foreach($result as $AttackData)
        {   
            if($AttackData["type_ID"] == $ID)
            {
                array_push($AttackDataList, $AttackData["name"]);
            }    
        }
        return $AttackDataList;
    }
?>

<!-- FONCTION QUI PERMET D'AFFICHER LES BUTTONS -->
<?php 
    function DisplayButtons($TypeDataList)
    {
        foreach($TypeDataList as $Data)
        {
            DisplayPokeButtons($Data);
        }
    }
?>

<!-- FONCTION QUI PERMET D'AFFICHER & RECUPERER L'URL DES PAGES -->
<?php 
    function LinkPages($Data)
    {
        $link = "pokeData.php?type=".$Data; 
        return $link;
    }
    function DisplayPokeButtons($Data)
    {
        echo '<button class="button" onclick=window.location="'.LinkPages($Data['id']).'">'. $Data['name'] .'</button>';
?>
        <span class="tooltip tooltip_left"><?php echo $Data['details']; ?></span>
<?php 
    } 
?>

<!-- FONCTION QUI PERMET D'AFFICHER UNE PARTIE D'UN TITRE SELON L'ID DU POKEMON -->
<?php 
    function DisplayTitle($title)
    {   
        $ValuePage = $_GET["type"];
        if($ValuePage == 1)
        {
            $ValuePage = "Combat";
        }
        else if($ValuePage == 2)
        {
            $ValuePage = "Dragon";
        }
        else if($ValuePage == 3)
        {
            $ValuePage = "Plante";
        }
        else if($ValuePage == 4)
        {
            $ValuePage = "Eau";
        }
        else if($ValuePage == 5)
        {
            $ValuePage = "Insecte";
        }
        else if($ValuePage == 6)
        {
            $ValuePage = "Psy";
        }
        else if($ValuePage == 7)
        {
            $ValuePage = "Fée";
        }
        else
        {
            $ValuePage = "ERREUR";
        }
        if($title == true)
        {
            echo "<h2>PokeData - Pokémon - " .$ValuePage. ":</h2>";
        }
        if($ValuePage == "ERREUR")
        {
            return false;
        }
        else
        {
            return $_GET["type"];
        }
    }
?>

<!-- FONCTION QUI PERMET D'AFFICHER LES POKEMONS SELON LE TYPE SELECTIONNER -->
<?php
    function DisplayPagePokemonType()
    {
        $ID = DisplayTitle(false);
        if($ID == false)
        {
            $ID = 0;
        }
        DisplayPokemon(GetDataPokeFromBDD("SELECT *, pokemons.name as fullName FROM pokemons INNER JOIN types ON pokemons.type = types.id WHERE type =".$ID));
    }
?>

<!-- FONCTION QUI PERMET DE STYLISER L'AFFICHER DES ATTAQUES -->
<?php 
    function DisplayPokemonAttacks($GetAttacksDataList)
    {
        $lastAttacksName = count($GetAttacksDataList);
        echo "- ";
        foreach($GetAttacksDataList as $AttacksData)
        {
            if(1 === --$lastAttacksName)
            {
             echo "<em>".$AttacksData."</em> et ";
            }
            else
            {
                if(0 === $lastAttacksName)
                {
                    echo "<em>".$AttacksData."</em>.";
                }
                else
                {
                    echo "<em>".$AttacksData."</em>, ";
                }
            }
        }
    }
?>

<!-- FONCTION QUI PERMET D'AFFICHER LES ATTAQUES DES POKEMONS SELON LE TYPE SELECTIONNER -->
<?php
    function DisplayPagePokemonTypeAttacks()
    {
        $ID = DisplayTitle(false);
        if($ID == false)
        {
            $ID = 0;
        }
        DisplayPokemonAttacks(GetDataAttacksFromBDD($ID));
    }
?>

<!-- FONCTION QUI PERMET DE RECUPERER UN CHIFFRE ET DE RENVOYER UN TEXTE SELON LE CHIFFRE -->
<?php 
    function GetTypeNameFromNumber($number)
    {
        if($number == 1)
        {
            $number = "Combat";
        }
        else if($number == 2)
        {
            $number = "Dragon";
        }
        else if($number == 3)
        {
            $number = "Plante";
        }
        else if($number == 4)
        {
            $number = "Eau";
        }
        else if($number == 5)
        {
            $number = "Insecte";
        }
        else if($number == 6)
        {
            $number = "Psy";
        }
        else if($number == 7)
        {
            $number = "Fée";
        }
        else
        {
            $number = "ERREUR";
        }
        return $number;
    }
?>

<!-- FONCTION QUI PERMET D'AFFICHER LE DERNIER POKEMON AJOUTER PAR L'UTILISATEUR -->
<?php
    $pokeNumber = $pokeName = $pokeType = $pokeImage  = ''; 
    $pokeNameError = '';


    /*  //TODO
        - Vérifier si tous les champs sont remplis 
        - Vérifier si les champs remplisent les conditions 
            - si le nom est correcte ou pas & qu'il existe ou pas dans la BBD
            - si le numéro est déja dans la BDD ou pas 
    */

    function PokeDataCheck()
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            global $pokeNumber;
            global $pokeName;
            global $pokeType;
            global $pokeImage;
            global $pokeNameError;

            $pokeNumber = check_input($_POST["pokeId"]);
            $pokeName = check_input($_POST["pokeName"]);
            //if (!preg_match("/^[a-zA-Z-' ]*$/",$pokeName)) 
            //{
            //    $pokeNameError = "* Le nom doit être composé uniquement de lettre et d'espace !";
            //}
            if(empty($_POST['pokeType']))
            {
                $_POST["pokeType"] = rand(1,7);
            }
            if($_POST["pokeType"] < 1 || $_POST["pokeType"] > 7)
            {
                $_POST["pokeType"] = rand(1,7);
            }
            $pokeType = check_input($_POST["pokeType"]);
            $pokeImage = check_input($_POST["pokeUrl"]);
            
            $data = getBDD();
            $sql = "INSERT INTO pokemons (number, name, type, image) VALUES ('".$_POST["pokeId"]."','".$_POST["pokeName"]."','".$_POST["pokeType"]."','".$_POST["pokeUrl"]."')";
            $data->exec($sql);
        }
    }

    function check_input($SQLdata)
    {
        $SQLdata = trim($SQLdata); //supprime les espaces (ou d'autres caractères) en début et fin de chaîne 
        $SQLdata = stripslashes($SQLdata); //Supprime les antislashs d'une chaîne
        $SQLdata = htmlspecialchars($SQLdata); //Convertit les caractères spéciaux en entités HTML
        return $SQLdata;
    }

    function DisplayLastPokeAddByUser($pokeNumber,$pokeName,$pokeType,$pokeImage)
    {
        global $pokeNumber;
        global $pokeName;
        global $pokeType;
        global $pokeImage;
        $pokeType = GetTypeNameFromNumber($pokeType);
?>      
        <table cellspacing="5" cellpadding="5" width="100%">
            <thead>
                <tr>
                    <th class="cell">Numéro</th>
                    <th class="cell">Nom</th>
                    <th class="cell">Type</th>
                    <th class="cell">Image</th>
                </tr>
            </thead>
            <tbody>
            <?php
                for($i=0; $i < 1 ; $i++)
                {
            ?>
            <tr>
                <td class="cell"><?php echo $pokeNumber; ?></td>
                <td class="cell"><?php echo $pokeName; ?></td>
                <td class="cell"><?php echo $pokeType; ?></td>
                <td class="cell"><img class="image" src="<?php echo $pokeImage; ?>" alt=""/></td>
            </tr>
            <?php 
                } 
            ?>
            </tbody>
        </table>
<?php 
    }
?>