// ONLOAD DISPLAY MODAL LOGIN IF NOT LOGIN
window.onload = function() 
{
  //document.getElementById("modalLoginLogout").style.display = "none";
  let getRoom = sessionStorage.getItem("homeRoom") || "none";
  let getPageResult = sessionStorage.getItem("resultGamePage")  || "none";
  DisplayModalLogin();
  if(getPageResult == "none" && getRoom == "outside" || getRoom == "lobby" || getRoom == "lobbyBefore" || getRoom == "lobby2Before" || getRoom == "library" || getRoom == "bedroom" || getRoom == "galery" || getRoom == "workshop")
  {
    OnloadTimer();
  }
  if(getPageResult == "none" && getRoom == "lobby" || getRoom == "library" || getRoom == "bedroom" || getRoom == "galery" || getRoom == "workshop") 
  {
    DisplayGameProgress();
  };
  if(getRoom == "outside" && getPageResult == "none") {onloadInFrontOfHouse();};
  if(getRoom == "lobbyBefore" && getPageResult == "none"){onloadHouseEntrance();};
  if(getRoom == "lobby2Before" && getPageResult == "none"){onloadHallHouse();};
  if(getRoom == "lobby" && getPageResult == "none"){onloadLobbyHouse();};
  if(getRoom == "library" && getPageResult == "none") {onloadLibrary();};
  if(getRoom == "bedroom" && getPageResult == "none") {onloadBedroom();};
  if(getRoom == "galery" && getPageResult == "none") {onloadGalery();};
  if(getRoom == "workshop" && getPageResult == "none") {onloadWorkshop();};
  if(getPageResult == "true") {onloadResultGame();};
  if(getPageResult == "none" && getRoom == "outsideEnd") {onloadGameEnd();};
}

function OnloadTimer()
{
  displayTextTimer();
  let statutStart = sessionStorage.getItem("startTimer");
  sessionStorage.getItem("timerStopTime");
  if (statutStart == "demarrer")
  {
    sessionStorage.setItem("timerStopTime","true");
    lauchTimer();
  }
}

