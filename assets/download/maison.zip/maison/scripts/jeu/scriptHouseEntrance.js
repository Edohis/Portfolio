function onloadHouseEntrance()
//document.onload = function() 
{
  sessionStorage.setItem("homeRoom","lobbyBefore");
}

function ActionHalfTurn()
{
  //bouton
  ShowContent("btn_run");
  HideContent("btn_halfTurn");
  //texte
  ShowContent("txt_halfTurn");
  HideContent("txt_getInsideHouse");
}

function ActionRun()
{
  //bouton
  ShowContent("btn_openFrontDoor");
  HideContent("btn_run");
  //texte
  ShowContent("txt_run");
  HideContent("txt_halfTurn");
}

function ActionOpenFrontDoor()
{
  //bouton
  ShowContent("btn_halfTurn2");
  HideContent("btn_openFrontDoor");
  //texte
  ShowContent("txt_openFrontDoor");
  HideContent("txt_run");
}

function ActionHalfTurn2()
{
  //bouton
  ShowContent("btn_halfTurn3");
  HideContent("btn_halfTurn2");
  //texte
  ShowContent("txt_halfTurn2");
  HideContent("txt_openFrontDoor");
}