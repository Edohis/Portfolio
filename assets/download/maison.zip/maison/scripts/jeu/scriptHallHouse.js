function onloadHallHouse()
//document.onload = function() 
{
  sessionStorage.setItem("homeRoom","lobby2Before");
}

function ActionGoToStaircase()
{
  //bouton
  ShowContent("btn_moveBody");
  HideContent("btn_staircase");
  //texte
  ShowContent("txt_moveBody");
  HideContent("txt_staircase");
}

function ActionMoveBody()
{
  //bouton
  ShowContent("btn_halfTurn");
  HideContent("btn_moveBody");
  //texte
  ShowContent("txt_halfTurn");
  HideContent("txt_moveBody");
}