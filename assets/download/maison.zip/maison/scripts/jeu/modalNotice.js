/* ########################################################################## */
/*
  << JS POUR LE MODAL DE TYPE NOTIFICATION >>
  =>Permet d'afficher un texte
*/
/* ########################################################################## */

/* ########################################################################## */

function ModalText(texte)
{
  let modal = document.getElementById("modalNotice");
  let txt = document.getElementById("modalNoticeContent");
  let quit = document.getElementById("modalNoticeQuit");
  modal.style.display = "block";
  txt.innerHTML = texte;
  
  quit.onclick = function() 
  {
    modal.style.display = "none";
    txt.innerHTML = "";

  }
  
  window.onclick = function(event) 
  {
    if (event.target == modal) 
    {
      modal.style.display = "none";
      txt.innerHTML = "";
    }
  }
  //
  let checkNav = sessionStorage.getItem("checkSideNavigation");
  if(checkNav == "true") 
  {
    CloseNavigation();
  }
}

function ModalTextPage(texte,link)
{
  let modal = document.getElementById("modalNotice");
  let txt = document.getElementById("modalNoticeContent");
  let quit = document.getElementById("modalNoticeQuit");
  modal.style.display = "block";
  txt.innerHTML = texte;
  
  quit.onclick = function() 
  {
    modal.style.display = "none";
    txt.innerHTML = "";
    location.replace(link);
  }
  
  window.onclick = function(event) 
  {
    if (event.target == modal) 
    {
      modal.style.display = "none";
      txt.innerHTML = "";
      location.replace(link);
    }
  }
  //
  let checkNav = sessionStorage.getItem("checkSideNavigation") || "true";
  if(checkNav == "true") 
  {
    CloseNavigation();
  }
}

function DisplayModalTextAction(title, content, buttons)
{
  document.getElementById("modalTextAction").style.display = "block";
  let getModalTitle = document.getElementById("modalTextActionTitle");
  getModalTitle.innerHTML = title;

  let getModalContent = document.getElementById("modalTextActionContent");
  getModalContent.innerHTML = content;

  let getModalFooter = document.getElementById("modalTextActionFooter");
  getModalFooter.innerHTML = buttons;
}

function ModalTextAction(addTitle,texte,nom,cible)
{
  let modal = document.getElementById("modalTextAction");
  let title = document.getElementById("modalTextActionTitle");
  let footer = document.getElementById('modalTextActionFooter');
  let content = document.getElementById("modalTextActionContent");
  
  modal.style.display = "block";
  title.innerHTML = addTitle;
  content.innerHTML = texte;
  
  let buttonAction = document.createElement('button');
  buttonAction.classList.add("modal_button");
  buttonAction.innerHTML = nom;
  buttonAction.id = cible;
  footer.appendChild(buttonAction);
  
  let buttonQuit = document.createElement("button");
  buttonQuit.innerHTML = "Quitter/Fermer";
  buttonQuit.classList.add("modal_button");
  buttonQuit.id = "modalTextActionQuit";
  footer.appendChild(buttonQuit);

  buttonQuit.onclick = function() { fermerModalGardiens(); }
  
  buttonQuit.onclick = function()
  {
    modal.style.display = "none"; 
    title.innerHTML = "";
    content.innerHTML = "";
    buttonAction.remove();
    buttonQuit.innerHTML = "";
    buttonQuit.remove();
  }
  
  DisplayModalActionText(modal,title,content,buttonAction,buttonQuit)

  window.onclick = function(event)
  {
    if (event.target == modal)
    {
      modal.style.display = "none"; 
      content.innerHTML = "";
      buttonAction.remove();
      buttonQuit.innerHTML = "";
      buttonQuit.remove();
    }
  }
}