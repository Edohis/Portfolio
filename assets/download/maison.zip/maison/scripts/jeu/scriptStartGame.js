let gameLaucher = true;
let setGameLaucher = sessionStorage.setItem("setGameLaucher",gameLaucher);