/* ########################################################################## */
/*
  ##################################
  ## IN THE WORKSHOP OF THE HOUSE ##
  ##################################
*/
/* ########################################################################## */

/* ########################################################################## */

/*  
  ---------------
  ## VARIABLES ## 
  ---------------
*/

let e6_wasResolved = false;
let e6_characterAResolved = false;
let e6_characterBResolved = false;
let e6_characterCResolved = false;
let e6_roomResolved = false;
let e6_numberResolved = 0;

/* ########################################################################## */

/*  
  ------------
  ## ONLOAD ## 
  ------------
*/

function onloadWorkshop()
//document.onload = function() 
{
  //DisplayModalLogin();
  //lauchTimer();
  let setRoom = sessionStorage.setItem("homeRoom","workshop")
  DisplayModalMission6Quete();
  let e6RoomResolved = sessionStorage.getItem("Enigme6RoomResolved");
  let e6CharacterAResolved = sessionStorage.getItem("Enigme6CharacterAResolved");
  let e6CharacterBResolved = sessionStorage.getItem("Enigme6CharacterBResolved");
  let e6CharacterCResolved = sessionStorage.getItem("Enigme6CharacterCResolved");
}

// DISPLAY MISSION - QUETE
function DisplayModalMission6Quete()
{
  DisplayModalMission("Enigme n°6 - Quête", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon>Objectif</h2><p>Bonjour Héritié, je suis le fantôme gardant <em>l'atelier</em> si vous souhaitez sortir de cette pièce vous devez résoudre les énigmes suivantes :</p><ul><li>Trouver l'identité de la personnalité (symbole '<iconify-icon data-icon='la:ghost'></iconify-icon>') représentée dans la pièce A (symbole '<iconify-icon data-icon='mdi-door'></iconify-icon> A').</li><li>Trouver l'identité de la personnalité (symbole '<iconify-icon data-icon='la:ghost'></iconify-icon>') représenté dans la pièce A (symbole '<iconify-icon data-icon='mdi-door'></iconify-icon> B').</li><li>Trouver l'identité de la personnalité (symbole '<iconify-icon data-icon='la:ghost'></iconify-icon>') représentée dans la pièce A (symbole '<iconify-icon data-icon='mdi-door'></iconify-icon> C').</li><li>Répondre à la question du fantôme de la pièce (symbole '<img src='../images/others/footprint.png' alt='Aller vers le fantôme' /><iconify-icon data-icon='la:ghost'></iconify-icon>').</li></ul>", "<bouton class='modal_button' onclick='DisplayModalMission6Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission6Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission6AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - RAPPEL
function DisplayModalMission6Rappel()
{
  DisplayModalMission("Enigme n°6 - Rappel", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Rappel</h2><ul><li>Pour obtenir vos énigmes, recherchez un fantôme (symbole <iconify-icon data-icon='la:ghost'></iconify-icon>), il y a au moins un fantôme par pièce.</li><li>Une fois chez le fantôme, vous pouvez lui demander :</li><ul><li>Vos énigmes (symbole <iconify-icon data-icon='akar-icons:question'></iconify-icon>).</li> <li>Obtenir de l'aide (symbole <iconify-icon data-icon='akar-icons:info'></iconify-icon>).</li><li>Répondre à l'énigme (symbole <iconify-icon data-icon='ic:baseline-question-answer'></iconify-icon>).</li></ul></ul>", "<bouton class='modal_button' onclick='DisplayModalMission6Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission6Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission6AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - AIDE
function DisplayModalMission6AideGeneral()
{
  DisplayModalMission("Enigme n°6 - Aide", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Conseil(s)</h2><ul><li>Divers indices sont présents dans la pièce pour vous aider à découvrir les identités des personnalités</li><li>Vous pouvez venir nous voir en cliquant sur le symbole '<img src='../images/others/footprint.png' alt='Aller vers le fantôme' /><iconify-icon data-icon='la:ghost'></iconify-icon>', pour obtenir de l'aide.</li></ul>", "<bouton class='modal_button' onclick='DisplayModalMission6Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission6Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission6AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}


/* ########################################################################## */

/*  
  -----------------------
  ## BAR ACTION DU BAS ## 
  -----------------------
*/

function HintGoalEnigme6(champ)
{
  ToggleHideAll('TextBlocGhost');
  ToggleHideAll('TextBlocGhostA');
  ToggleHideAll('TextBlocGhostB');
  ToggleHideAll('TextBlocGhostC');
  if (champ == "goal")
  {
    ToggleDisplay('TextBlocDefault', 'txtE6_', '1')
  }
  if (champ == "hint")
  {
    ToggleDisplay('TextBlocDefault', 'txtE6_', '2');
  }
}

/* ########################################################################## */

/*  
  ----------
  ## ROOM ## 
  ----------
*/

function DislayTextForBooks(valeur)
{
  if(valeur == "books1" || valeur == "books2" || valeur == "books3" || valeur == "books4" || valeur == "books5")
  {
    ModalText("Juste des livres.");
  }
}

function DisplayTextForTable(valeur)
{
  if(valeur == "table1" || valeur == "table2" || valeur == "table3")
  {
    ModalText("Juste une table " + valeur);
  }
}

// ALLER VERS LE FANTÔME DE LA PIECE
function ActionGoToGhostOfRoom(valeur)
{
  ToggleHideAll('TextBlocDefault');
  if(valeur == "mainRoom")
  {
    ActionGoTo("hall/ghosts.jpg","baE6_workshop","baE6_ghost");
  }
  if(valeur == "roomA")
  {
    ActionGoTo('hall/ghosts.jpg','baE6_roomA','baE6_roomAGhost');
  }
  if(valeur == "roomB")
  {
    ActionGoTo('hall/ghosts.jpg','baE6_roomB','baE6_roomBGhost');
  }
  if(valeur == "roomC")
  {
    ActionGoTo('hall/ghosts.jpg','baE6_roomC','baE6_roomCGhost');
  }
}

/* ########################################################################## */

/*
  -----------
  ## GHOST ## 
  -----------
*/

// RETOURNER VERS LA PIECE PRINCIPAL
function ActionGoToGhostToRoom(valeur)
{
  ToggleHideAll('TextBlocDefault');
  if (valeur == "mainRoom")
  {
    //ToggleHideAll('TextBlocGhost');
    //HideActionBloc("baE6_ghostAnswer");
    ActionGoTo('workshop/workshop.jpg','baE6_ghost','baE6_workshop');
  }
  if (valeur == "roomA")
  {
    ActionGoTo('workshop/laboratory.jpg','baE6_roomAGhost','baE6_roomA');
  }
  if (valeur == "roomB")
  {
    ActionGoTo('workshop/health.jpg','baE6_roomBGhost','baE6_roomB');
  }
  if (valeur == "roomC")
  {
    ActionGoTo('workshop/physicsLab.jpg','baE6_roomCGhost','baE6_roomC');
  }
}

// ACTION = INTERAGIR AVEC LES GARDIENS
function ActionInterragirGhost(room,valeur)
{
  ToggleHideAll('TextBlocDefault');
  if(room == "mainRoom")
  {
    if (valeur == "question")
    {
      DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Enigme de la pièce", "Avant-propos", "enigme6pieceIntro", "Enigme", "enigme6pieceQuest");
    }
    if (valeur == "aide")
    {
      DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Une info ?", "Astuce", "e6astuces", "Indice", "e6indices");
    }
    if (valeur == "repondre")
    {
      if (e6_characterAResolved == true && e6_characterBResolved == true && e6_characterCResolved == true)
      {
        //Pour répondre à l'énigme
        ActionReplyToGhost("roomEnigme6");
      }
      else
      {
        //Impossible de répondre 
        ModalText("<p>Vous ne pouvez pas encore répondre à cette énigme !</p<p>Vous devez d'abord résoudre les autres énigmes de cette pièce !</p>");
      }
    }
  }
  if(room == "roomA")
  {
    if (valeur == "question")
    {
      DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Enigme du personnage A", "Avant-propos", "enigme6characterAIntro", "Enigme", "enigme6characterAQuest");
    }
    if (valeur == "repondre")
    {
      ActionReplyToGhost("characterAEnigme6");
    }
  }
  if(room == "roomB")
  {
    if (valeur == "question")
    {
      DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Enigme du personnage B", "Avant-propos", "enigme6characterBIntro", "Enigme", "enigme6characterBQuest");
    }
    if (valeur == "repondre")
    {
      ActionReplyToGhost("characterBEnigme6");
    }
  }
  if(room == "roomC")
  {
    if (valeur == "question")
    {
      DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Enigme du personnage C", "Avant-propos", "enigme6characterCIntro", "Enigme", "enigme6characterCQuest");
    }
    if (valeur == "repondre")
    {
      ActionReplyToGhost("characterCEnigme6");
    }
  }
}

// AFFICHAGE MODAL INTERAGIR AVEC LES GARDIENS
function DisplayModalInteractionRoom(createSection, contentOne, addContentOneId, contentTwo, addContentTwoId)
{
  if (addContentOneId == "enigme6pieceIntro")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p class="">Héritié si vous souhaitez avoir votre avant-dernière énigme,<br />vous devez tout d\'abord résoudre les énigmes des autres fantômes présents dans la pièce. (symbole : \'<iconify-icon data-icon="la:ghost"></iconify-icon> A\',\'<iconify-icon data-icon="la:ghost"></iconify-icon> B\',\'<iconify-icon data-icon="la:ghost"></iconify-icon> C\'). </p><p class="">Vous pouvez tout de même voir l\'énigme en cliquant sur le bouton <em>"Enigme"</em>.</p>';
    }
  }
  if (addContentTwoId == "enigme6pieceQuest")
  {
    contentTwo.onclick = function()
    {
      if(e6_characterAResolved == true && e6_characterBResolved == true && e6_characterCResolved == true)
      {
        createSection.innerHTML = '<p class="modal_text_center_to_justify">Si vous souhaitez obtenir les indices du message finale vous devez me donner le code que vous avez obtenu selon les incides suivants : Code = <span class="blockInline indiceC">C</span>-<span class="blockInline indiceB">B</span>-<span class="blockInline indiceA">A</span></span>.</p><p class="modal_text_center_to_justify">Indices récupérer : A = 19<span class="indiceA">11</span> | B = 1<span class="indiceB">82</span>2 | C = <span class="indiceC">19</span>55</p>';
      }
      else
      {
        createSection.innerHTML = '<p>Vous devez répondre aux énigmes des fantômes ("<iconify-icon data-icon="la:ghost"></iconify-icon> A", "<iconify-icon data-icon="la:ghost"></iconify-icon> B", "<iconify-icon data-icon="la:ghost"></iconify-icon> C")<br />présents dans les pièces ("<iconify-icon data-icon="mdi-door"></iconify-icon> A", "<iconify-icon data-icon="mdi-door"></iconify-icon> B", "<iconify-icon data-icon="mdi-door"></iconify-icon> C").</p>'
      }
    }
  }
  if (addContentOneId == "e6astuces")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>Généralement le thème de la pièce est un gros indice pour la réponse d\'au moins une des énigmes présentes dans chaque pièce de la maison.</p><p>cette pièce contrairement aux autres, vous propose de découvrir le nom de trois personnalités.</p>';
    }
  }
  if (addContentTwoId == "e6indices")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Des indices sur l\'identité de chaque personnalité de cette pièce sont présents un peu partout dans la pièce.</p>';
    }
  }
  /**ENIGME CHARACTER A & B & C**/
  if (addContentOneId == "enigme6characterAIntro" || addContentOneId == "enigme6characterBIntro" || addContentOneId == "enigme6characterCIntro")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>Bonjour à toi, Héritié</p><p>Si tu souhaites obtenir mon morceau de code pour quitter <em>l\'atelier</em>,<br />il te suffit de répondre à mon énigme en cliquant sur le bouton "Énigme".</p>';
    }
  }
  /**ENIGME CHARACTER A**/
  if(addContentTwoId == "enigme6characterAQuest")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Enigme - Qui suis-je ?<br />"Je suis née en juillet 1934". "Je suis polonais et française par mariage".</p><p>"Je suis physicienne et chimiste". "J\'ai travaillé sur la radioactivité naturelle et fait la découverte du radium et du polomium".</p><p>"J\'ai reçu le prix Nobel de physique en 1903 et le prix Nobel de chimie en 1911".</p><p>"Qui suis-je ?"</p>';
    }
  }
  /**ENIGME CHARACTER B**/
  if(addContentTwoId == "enigme6characterBQuest")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Enigme - Qui suis-je ?<br />"Je suis né en décembre 1822". "Je suis français".</p><p>"Je suis scientifique, chimiste et physicien de formation".</p><p>"Je suis un pionner de la microbiologie, connu pour avois mis au point un vaccin contre la rage".</p><p>"Qui suis-je ?"</p>';
    }
  }
  /**ENIGME CHARACTER C**/
  if(addContentTwoId == "enigme6characterCQuest")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Enigme - Qui suis-je ?<br />"Je suis né en mars 1879". "Je suis allemand".</p><p>"Je suis physicien théoricien". "J\'ai publié comme théoroe : la relativité restreinte, la gravitation (relativité générale)".</p><p>"J\'ai contribué à la mécanique quantique et la cosomologie. J\'ai reçu le prix Nobel de physique de 1921".</p><p>"Qui suis-je ?"</p>';
    }
  }
}


// ACTION = REPONDRE A UN E!NIGME (FANTOME)
function ActionReplyToGhost(valeur)
{
  if(valeur == "roomEnigme6") // ENIGME : DONNER LE CODE TROUVER
  {
    let reponsePossible = ["198211"]; //Uniquement un code possible 
    InputAnswer("number", valeur, "Quel est le code à 6 chiffres ?",reponsePossible);
  }
  if(valeur == "characterAEnigme6")
  {
    let reponsePossible = ["Marie Curie","marie curie","MARIE CURIE"];
    InputAnswer("text", valeur, "Quelle est l'identité de la personnalité (de la pièce A) ?", reponsePossible);
  }
  if(valeur == "characterBEnigme6")
  {
    let reponsePossible = ["Louis Pasteur","louis pasteur","LOUIS PASTEUR"];
    InputAnswer("text", valeur, "Quelle est l'identité de la personnalité (de la pièce B) ?", reponsePossible);
  }
  if(valeur == "characterCEnigme6")
  {
    let reponsePossible = ["Albert Einstein","albert einstein","ALBERT EINSTEIN"];
    InputAnswer("text", valeur, "Quelle est l'identité de la personnalité (de la pièce C) ?", reponsePossible);
  }
}

// DISPLAY = CACHER LES BUTTONS DE REPONSE QUAND REPONDU
function HidePossibiltyOfAnswerForEnigmeSix(valeur)
{
  if(valeur == "roomEnigme6")
  {
    //Permet d'indiquer que vous avez répondu correctement
    e6_roomResolved = true;
    sessionStorage.setItem("Enigme6RoomResolved",e6_roomResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    AddRemoveClass('ba6G_answerEnigme',false,'baE6_ghost');
    EditIdDisplay('ba6G_answerEnigme','none');
  }
  if(valeur == "characterAEnigme6")
  {
    e6_characterAResolved = true;
    sessionStorage.setItem("Enigme6CharacterAResolved",e6_characterAResolved);
  }
  if(valeur == "characterBEnigme6")
  {
    e6_characterBResolved = true;
    sessionStorage.setItem("Enigme6CharacterBResolved",e6_characterBResolved);
  }
  if(valeur == "characterCEnigme6")
  {
    e6_characterCResolved = true;
    sessionStorage.setItem("Enigme6CharacterCResolved",e6_characterCResolved);
  }
  if(e6_characterAResolved == true && e6_characterBResolved == true && e6_characterCResolved == true && e6_roomResolved == true)
  {
    e6_wasResolved = true;
  }
  HidePossibilityOfAnswerForEnigme6(valeur)
}

function HidePossibilityOfAnswerForEnigme6(valeur)
{
  
  if(valeur == "roomEnigme6")
  {
    if (e6_wasResolved == true)
    {
      AddRemoveClass("ba6G_answerEnigme", false, "baE6_ghost");
      EditIdDisplay("ba6G_answerEnigme", "none");
      //ChangePage("roomlobbyHouse.html");
      ModalTextPage("Vous vous déplacez vers la porte....","lobbyHouse.html")
      //ChangePage("lobbyHouse.html",6000);
      SetPageLocalisation('lobby');
    }
  }
  if(valeur == "characterAEnigme6")
  {
    //Permet de retirer l'action de son bloc d'action et de le cacher
    HideActionBloc('baE6_roomAGhost');
    ActionGoTo('workshop/laboratory.jpg','baE6_roomAGhost','baE6_roomA');
    RemoveElement("ba6RA_goToGhost");
  }
  if(valeur == "characterBEnigme6")
  {
    //Permet de retirer l'action de son bloc d'action et de le cacher
    HideActionBloc('baE6_roomBGhost');
    ActionGoTo('workshop/health.jpg','baE6_roomBGhost','baE6_roomB');
    RemoveElement("ba6RB_goToGhost"); 
  }
  if(valeur == "characterCEnigme6")
  {
    //Permet de retirer l'action de son bloc d'action et de le cacher
    HideActionBloc('baE6_roomCGhost');
    ActionGoTo('workshop/physicsLab.jpg','baE6_roomCGhost','baE6_roomC');
    RemoveElement("ba6RC_goToGhost");
  }
}
/* ########################################################################## */