/* ########################################################################## */
/*
  << JS LISTE DES DIVERS FONCTIONS POUR LE JEU >>
*/
/* ########################################################################## */

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## SHOW & HIDE CONTENT ## 
  => permet de montrer ou cacher des éléments de groupe diverses.
  => surtout utiliser pour les actions de la bar du bas pendant les dialogues.
*/
/* -------------------------------------------------------------------------- */

function ShowContent() {
  if (arguments.length > 0) {
    for (var i = 0; i < arguments.length; i++) {
      document.getElementById(arguments[i]).style.display = "block";
    }
  }
}

function HideContent() {
  if (arguments.length > 0) {
    for (var i = 0; i < arguments.length; i++) {
      document.getElementById(arguments[i]).style.display = "none";
    }
  }
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## TOGGLE CONTENT ## 
  => permet d'afficher ou de cacher des éléments d'un même groupe
  => surtout utiliser pour afficher uniquement un texte selon un groupe dans la 
      zone de texte 
*/
/* -------------------------------------------------------------------------- */

function ToggleDisplay(classe, nom, data)
{
  let element = document.getElementById(nom + data);
  let champ = document.getElementById("areaText")
  if (element.classList.contains("c_visible"))
  {
    element.classList.remove("c_visible");
    element.classList.add("c_hide");
    champ.classList.remove("elements_background");
  }
  else
  {
    if (element.classList.contains("c_hide"))
    {
      element.classList.remove("c_hide")
    }
    element.classList.add("c_visible");
    champ.classList.add("elements_background");
  }
  ToggleHide(classe, data)
}

function ToggleHide(classe, data)
{
  let list = document.getElementsByClassName(classe);
  for (let i = 0, len = list.length; i < len; i++)
  {
    if (i != data - 1)
    {
      list[i].classList.remove('c_visible');
      list[i].classList.add("c_hide");
    }
  }
}

function ToggleHideAll(classe)
{
  let list = document.getElementsByClassName(classe);
  let champ = document.getElementById("areaText")
  for (let i = 0, len = list.length; i < len; i++)
  {
    list[i].classList.remove('c_visible');
    list[i].classList.add("c_hide");
    champ.classList.remove("elements_background");
  }
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## CHANGER D'IMAGE ## 
*/
/* -------------------------------------------------------------------------- */

function ReplacePicture(img)
{
  document.getElementById("image_01").src = '../images/'+img; 
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## AFFICHER/CACHER UN BLOC D'ACTION ## 
*/
/* -------------------------------------------------------------------------- */

function HideActionBloc(nom)
{
  for(let x of document.querySelectorAll('.'+nom))
  {
    x.style.display = "none";
  }
}

function DisplayActionBloc(nom)
{
  for(let x of document.querySelectorAll('.'+nom))
  {
    x.style.display = "block";
  }
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## ALLER VERS ## 
  => permet de ce déplacer entre les divers lieux
  => utiliser pour les actions effectuent des déplacements vers un lieu
*/
/* -------------------------------------------------------------------------- */

function ActionGoTo(img, cacher, montrer, action = null)
{
  //Permet de changer l'image
  ReplacePicture(img);
  //Permet de cacher tous les boutons d'action de "baCacher"
  HideActionBloc(cacher);
  //Permet d'afficher tous les boutons d'action de "baMontrer"
  DisplayActionBloc(montrer);
  //Pour des actions spéciales
  if (action !== null)
  {
    if (action == "doorGoToHouse")
    {
      HideBlocActionCarpet();
    }
    else if (action == "houseGoToDoor")
    {
      DisplayBlocActionCarpet();
    }
    else
    {
      console.log("ERREUR - Function ActionAllersVers")
    }
  }
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## AJOUTER/RETIRER UNE CLASSE ## 
  => permet de ce déplacer entre les divers lieux
  => utiliser pour les actions effectuent des déplacements vers un lieu
*/
/* -------------------------------------------------------------------------- */

function AddRemoveClass(nom, ajout, type)
{
  let dom = document.getElementById(nom);
  if(ajout == true)
  {
    dom.classList.add(type);
  }
  else if(ajout == false)
  {
    dom.classList.remove(type);
  }
  else 
  {
    alert("ERREUR - Function AffichageDom" + nom + " " + ajout + " " + " " + type)
  }
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## MODIFIER LE STYLE D'AFFICHAGE D'UN ID ## 
  => permet de ce déplacer entre les divers lieux
  => utiliser pour les actions effectuent des déplacements vers un lieu
*/
/* -------------------------------------------------------------------------- */

function EditIdDisplay(nom, type)
{
 let elementaffichage = document.getElementById(nom);
 elementaffichage.style.display = type;
}


/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## SUPPRIMER UN ELEMENT PAR SON ID ## 
  => permet de supprimer un élément
*/
/* -------------------------------------------------------------------------- */

function RemoveElement(nom)
{
 let element = document.getElementById(nom);
 element.remove();
}


/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## PERMET D'AJOUTER UN LIEN A UNE BALISE ID ## 
  => permet de ce déplacer entre les divers lieux
  => utiliser pour les actions effectuent des déplacements vers un lieu
*/
/* -------------------------------------------------------------------------- */

function AddLinkToButton(nom, lien)
{
  let txtLink = document.getElementById(nom);
  txtLink.href = lien;
  stopTimer()
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## PERMET D'AJOUTER UN LIEN A UNE BALISE ID ## 
  => permet de ce déplacer entre les divers lieux
  => utiliser pour les actions effectuent des déplacements vers un lieu
*
/* -------------------------------------------------------------------------- */

function ChangePage(lien,duration)
{
  let duree = duration 
  if (duree == 0 || duree == '' || duree == null)
  {
    duree = 1000;
    duration = duree
  }
  let getRoom = sessionStorage.getItem("homeRoom") || "none";
  let getPageResult = sessionStorage.getItem("resultGamePage")  || "none";
  if(getPageResult == "none" && getRoom == "outside" || getRoom == "lobby" || getRoom == "lobbyBefore" || getRoom == "lobby2Before" || getRoom == "library" || getRoom == "bedroom" || getRoom == "galery" || getRoom == "workshop")
  {
    stopTimer();
  }
  setTimeout(function(){
    location.replace(lien);
  },duration);
}

function SetPageLocalisation(name)
{
  sessionStorage.setItem("homeRoom",name);
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## PERMET D'AFFICHER LES MODALS D'INTERACTION AVEC LES FANTÔMES ## 
  => permet d'afficher un modal avec un contenu
*/
/* -------------------------------------------------------------------------- */

function DisplayModalInteractionAffichage(idModal, idTitle, idSection, idButtons, idQuit, addTitle, addContentOne, addContentOneId, addContentTwo, addContentTwoId)
{
  document.getElementById(idModal).style.display = "block";
  let title = document.getElementById(idTitle);
  title.innerHTML = addTitle;

  let createSection = document.getElementById(idSection);
  createSection.innerHTML = "Cliquez sur un des boutons pour afficher un texte. Pour fermer cliquer sur le bouton fermer."

  let button = document.getElementById(idButtons);
  let contentOne = document.createElement('button');
  contentOne.innerHTML = addContentOne;
  contentOne.classList.add("modal_button");
  contentOne.id = addContentOneId;
  button.appendChild(contentOne);

  let contentTwo = document.createElement("button");
  contentTwo.innerHTML = addContentTwo;
  contentTwo.classList.add("modal_button");
  contentTwo.id = addContentTwoId;
  button.appendChild(contentTwo);
    
  let buttonQuit = document.createElement("button");
  buttonQuit.innerHTML = "Fermer";
  buttonQuit.classList.add("modal_button");
  buttonQuit.id = idQuit;
  button.appendChild(buttonQuit);

  buttonQuit.onclick = function() { fermerModalGardiens(); }

  DisplayModalInteractionRoom(createSection, contentOne, addContentOneId, contentTwo, addContentTwoId);
  
  function fermerModalGardiens()
  {
    document.getElementById(idModal).style.display = "none";
    title.innerHTML = "";
    createSection.innerHTML = "";
    contentOne.remove();
    contentTwo.remove();
    buttonQuit.innerHTML = "";
    buttonQuit.remove();
  };
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## PERMET D'AFFICHER LES MODALS DE MISSION POUR LES ENIGMES ## 
  => permet d'afficher un modal avec un contenu expliquant ce qu'il faut faire
*/
/* -------------------------------------------------------------------------- */

function DisplayModalMission(title, content, buttons)
{
  document.getElementById("modalMission").style.display = "block";
  let getModalTitle = document.getElementById("modalMissionTitle");
  getModalTitle.innerHTML = title;

  let getModalContent = document.getElementById("modalMissionContent");
  getModalContent.innerHTML = content;

  let getModalFooter = document.getElementById("modalMissionFooter");
  getModalFooter.innerHTML = buttons;
  stopTimer();
}

function ModalMissionClose()
{
  document.getElementById("modalMission").style.display = "none";
  lauchTimer()
}


/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## PERMET D'AFFICHER LES MODALS DE PROGRESSION DU JEU ## 
  => permet d'afficher un modal montrent l'avancement dans le jeu
*/
/* -------------------------------------------------------------------------- */

function DisplayModalGameProgress(title,content,buttons)
{
  document.getElementById("modalGameProgress").style.display = "block";
  let getModalTitle = document.getElementById("modalGameProgressTitle");
  getModalTitle.innerHTML = title;;
  
  let getModalContent = document.getElementById("modalGameProgressContent");
  getModalContent.innerHTML = content;

  let getModalFooter = document.getElementById("modalGameProgressButtons");
  getModalFooter.innerHTML = buttons;
  stopTimer();
}

function ModalGameProgressClose()
{
  document.getElementById("modalGameProgress").style.display = "none";
  lauchTimer();
}

function ModalGameProgressAndInventoryEnigmeClose()
{
  document.getElementById("modalGameProgress").style.display = "none";
  DisplayInventory('inventoryContainer','inventory_','1');
  lauchTimer();
}