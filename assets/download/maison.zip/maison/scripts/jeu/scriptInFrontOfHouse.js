/* ########################################################################## */
/*
  ###########################
  ## IN FRONT OF THE HOUSE ##
  ###########################
*/
/* ########################################################################## */

/* ########################################################################## */

/*  
  ---------------
  ## VARIABLES ## 
  ---------------
*/  

let e1_mailboxIsOpen = false;
let e1_hasKeyInsideMailbox = false;
let e1_hasKeyMailbox = false;
let e1_numberOfKeyInInventory = 0;
let e1_hasKeyFrontDoor = false;
let e1_flowerPotThreeChosen = false;
let e1_flowerPotFiveChosen = false;
let e1_discoveredKeyInFlowerPotFive = false;
let e1_discoveredHintBelowFlowerPotThree = false;
let e1_hasHintBelowFlowerPotThree = false;
let e1_carpetMove = false;
let e1_flowerPotPutDown = true;

/* ########################################################################## */

/*  
  ------------
  ## ONLOAD ## 
  ------------
*/ 

function onloadInFrontOfHouse()
//document.onload = function() 
{
  sessionStorage.setItem("homeRoom","outside");
}

/* ########################################################################## */

/*  
  -----------------------
  ## DEVANT LE PORTAIL ## 
  -----------------------
*/

// ACTION = PASSER DE LA BOITE AUX LETTRES VERS LE PORTAIL
function ActionGoBackToEntranceGate()
{
  ActionGoTo('inFrontOfHouse/entranceGate.jpg','baE1_mailboxOpen','baE1_entranceGate');
  e1_mailboxIsOpen = true;
}

// ACTION = ALLER VERS LA BOITE AUX LETTRES 
function ActionGoToMailbox() 
{
  //Permet de cacher le bloc d'action "ENTRANCE GATE"
  HideActionBloc('baE1_entranceGate')
  // SITUATION - La boite aux lettres est fermer 
  if(e1_mailboxIsOpen == false) 
  {
    //Permet de changer l'image 
    ReplacePicture('inFrontOfHouse/mailbox.jpg');
    //Permet d'afficher un bloc d'action "MAILBOX"
    DisplayActionBloc('baE1_mailbox');
  }
  // SITUAION - La boite aux lettres est ouverte
  else 
  {
    //Permet de changer l'image 
    ReplacePicture('inFrontOfHouse/mailboxOpen.jpg');
    //Si la clé a était enlever on n'affiche pas l'action 
    if(e1_hasKeyInsideMailbox==true)
    {
      AddRemoveClass('ba1EGMBO_takeKey', false, 'baE1_mailboxOpen');
      EditIdDisplay('ba1EGMBO_takeKey', 'none')
    }
    //Permet d'afficher les actions du bloc "MAILBOX OPEN"
    DisplayActionBloc('baE1_mailboxOpen');
  }
}

// ACTION = OUVRIR BOITE AUX LETTRES
function ActionOpenMailbox()
{
  //Le joueur ne posséde pas la clé de la boite aux lettres
  if (e1_hasKeyMailbox == false)
  {
    //texte/notification
    ModalText('<p>Vous tentez d\'ouvrir la boîte aux lettres, mais sans succès. Vous comprenez, en regardant la boîte aux lettres qu\'il vous faut une clé pour l\'ouvrir. Il n\'y a plus qu\'à la chercher.</p>');
  }
  //Le joueur posséde la clé de la boite aux lettres 
  else
  {
    //texte/notification
    ModalText("<p>Vous mettez la clé avec l\'étiquette &laquo; BAL &raquo; que vous avez trouvée vers la maison et réussissez à ouvrir la boîte aux lettres.</p>");
    //changer l'image
    ReplacePicture('inFrontOfHouse/mailboxOpen.jpg')
    //Permet de cacher le bloc d'action "MAILBOX"
    HideActionBloc('baE1_mailbox')
    //Permet d'afficher le bloc d'action "MAILBOX OPEN"
    DisplayActionBloc('baE1_mailboxOpen')
  }
}

// ACTION = REGARDER DANS LA BOITE AUX LETTRES
function ActionLookInsideMailbox()
{
  //Si la clé de la boite aux lettre n'a pas était prise
  if (e1_hasKeyInsideMailbox == false)
  {
    ModalText("<p>En observant l'intérieur de la boîte aux lettres, via l'ouverture, vous pouvez voir qu'il y a un objet au fond. Peut-être une clé ?</p>");
  }
  //Si la clé de la boite aux lettres a était prise
  else
  {
    ModalText("<p>Vous observez l'intérieur de la boîte aux lettres, mais ne voyez plus rien à l'intérieur autres que la poussière.</p>");
  }
}

// ACTION = PRENDRE LA CLE SITUE DANS LA BOITE AUX LETTRES
function ActionTakeKeyInsideMailbox()
{
  ModalText("<p>Vous avez obtenu la clé de la boîte aux lettres</p>");
  e1_numberOfKeyInInventory += 1
  e1_hasKeyInsideMailbox = true;
  AddRemoveClass('ba1EGMBO_takeKey', false, 'baE1_mailboxOpen');
  EditIdDisplay('ba1EGMBO_takeKey', 'none')
}

// ACTION = FERMER BOITE AUX LETTRES
function ActionCloseMailbox()
{
  //Permet de changer l'image 
  ReplacePicture('inFrontOfHouse/mailbox.jpg');
  //Permet de cacher le bloc d'action 
  HideActionBloc('baE1_mailboxOpen')
  //Permet de cacher l'action "prendre la clé"
  if (e1_hasKeyInsideMailbox == true)
  {
    AddRemoveClass('ba1EGMBO_takeKey', false, 'baE1_mailboxOpen');
    EditIdDisplay('ba1EGMBO_takeKey', 'none')
  }
  //Permet d'afficher le bloc d'action 
  DisplayActionBloc('baE1_mailbox');
  //Permet d'indiquer que la boite aux lettres a était fermer 
  e1_mailboxIsOpen = false;
}
/* ########################################################################## */

/*  
  ---------------
  ## LE JARDIN ## 
  ---------------
*/

// ACTION = PORTE DU JARDIN
function ActionGardenDoor()
{
  ModalText("<p>Vous tentez d'ouvrir la porte, mais sans succès.</p>");
}
/* ########################################################################## */

/*  
  --------------
  ## LA SERRE ## 
  --------------
*/

// ACTION = PORTE DE LA SERRE
function ActionGreenhouseDoor()
{
  ModalText("<p>Vous tentez d'ouvrir la porte, mais sans succès.</p>");
}
/* ########################################################################## */

/*  
  -----------------------------------------
  ## VERS LA PORTE D'ENTREE DE LA MAISON ## 
  -----------------------------------------
*/

// ACTION = OUVRIR LE PORTE D'ENTREE
function ActionOpenFrontDoor()
{
  if (e1_hasKeyFrontDoor == false)
  {
    ModalText("<p>Vous tentez d'ouvrir la porte, mais sans succès.</p><p>Vous n'avez pas la clé de la porte d'entrée, relisez les indices laissés par votre défunt oncle.</p>");
  }
  //Possede la clé de la porte d'entrée
  else
  {
    ModalTextPage("<p>Vous mettez la clé ayant l'étiquette &laquo; PE &raquo; dans la serrure de la porte et réussissez ainsi à ouvrir la porte d'entrée</p><p>rentrant ainsi à l'intérieur.</p>","houseEntrance.html");
    //ChangePage("houseEntrance.html",6000);
    SetPageLocalisation('lobbyBefore');
  }
}

// AFFICHAGE = Permet d'afficher les actions basiques d'un pot de fleur
function DisplayActionFlowerPots()
{
  //Permet de changer l'image 
  ReplacePicture('inFrontOfHouse/flowerPot.jpg');
  //Permet de cacher un bloc d'action "Bloc porte entrée"
  HideActionBloc('baE1_frontDoor');
  //Permet d'afficher un bloc d'action "Bloc pot"
  DisplayActionBloc('baE1_flowerPot');
  //Permet de cacher un bloc d'action "Prendre la clé du tapis ?"
  HideActionBloc('baE1_carpetKey')
}

// ACTION = POT DE FLEUR SANS ACTION SPECIAL
function ActionFlowerPotNormal()
{
  DisplayActionFlowerPots()
}

// ACTION = POT DE FLEUR 3
function ActionFlowerPotThree()
{
  //Permet d'afficher les actions basiques
  DisplayActionFlowerPots()
  e1_flowerPotThreeChosen = true;
}

// ACTION = POT DE FLEUR 5
function ActionFlowerPotFive()
{
  //Permet d'afficher les actions basiques
  DisplayActionFlowerPots()
  //Permet d'indiquer que le pot 5 a était choisis
  e1_flowerPotFiveChosen = true;
  //Permet d'afficher un bloc d'action selon des conditions
  if(e1_discoveredKeyInFlowerPotFive == true && e1_hasKeyFrontDoor == false)
  {
    //Permet d'afficher un bloc d'action 
    DisplayActionBloc('baE1_flowerPotKey');
  }
}

// ACTION = REGARDER DANS LE POT
function ActionLookInsideFlowerPot()
{
  if(e1_flowerPotFiveChosen == true)
  {
    if(e1_discoveredKeyInFlowerPotFive == false)
    {
      ModalText("<p>Il vous semble voir une clé enterrée au centre du pot.</p>");
      e1_discoveredKeyInFlowerPotFive = true;
      //Permet d'afficher un bloc d'action 
      DisplayActionBloc('baE1_flowerPotKey');
      return;
    }
    if(e1_discoveredKeyInFlowerPotFive == true && e1_hasKeyFrontDoor == false)
    {
      ModalText("<p>La clé est toujours présente et enterrée à la même place.</p>")
    }
    else 
    {
      ModalText("<p>Des plantes.</p>")
    }
  }
  else
  {
    ModalText("<p>Des plantes.</p>");
  }
}

// ACTION = SOULEVER LE POT
function ActionCarryFlowerPot()
{
  ModalText("<p>Vous soulevez le pot de fleur mais vous ne voyez rien.</p>")
  //Permet de retirer une action d'un bloc action et de la cacher
  AddRemoveClass("ba1FDFP_carryFlowerPot",false,"baE1_flowerPot");
  EditIdDisplay("ba1FDFP_carryFlowerPot", 'none');
  //Permet d'afficher un bloc d'action  
  DisplayActionBloc('baE1_flowerPotCarry')
  //Permet d'afficher un bloc d'action si condition
  if(e1_discoveredHintBelowFlowerPotThree == true && e1_hasHintBelowFlowerPotThree == false)
  {
    //Permet d'afficher un bloc d'action 
    DisplayActionBloc('baE1_flowerPotHint');
    
  }
  //Permet d'indiquer que le pot a était soulever
  e1_flowerPotPutDown = false;
}

// ACTION = POSER LE POT 
function ActionPutDownFlowerPot()
{
  ModalText("<p>Vous décidez de poser le pot.</p>")
  //Permet de cacher un bloc d'action
  HideActionBloc("baE1_flowerPotCarry");
  //(NECCESSAIRE ?) Permet d'indiquer que le pot est poser
  e1_flowerPotPutDown = true;
  //Permet d'insérer une action à son bloc d'action d'origine et de l'afficher
  AddRemoveClass("ba1FDFP_carryFlowerPot",true,"baE1_flowerPot");
  EditIdDisplay("ba1FDFP_carryFlowerPot", 'block');
}

// ACTION = REGARDER SOUS LE DESSOUS DU POT 
function ActionLookBelowFlowerPot()
{
  if(e1_flowerPotThreeChosen == true)
  {
    if(e1_discoveredHintBelowFlowerPotThree == false)
    {
      ModalText("<p>Il vous semble voir un post-it sous le pot.</p>");
      e1_discoveredHintBelowFlowerPotThree = true;
      //Permet d'afficher un bloc d'action 
      DisplayActionBloc('baE1_flowerPotHint');
      return;
    }
    if(e1_discoveredHintBelowFlowerPotThree == true && e1_hasHintBelowFlowerPotThree == false)
    {
      ModalText("<p>Le post-it est toujours présent à la même place.</p>")
    }
    else 
    {
      ModalText("<p>Vous ne voyez rien d'interressant !</p>")
    }
  }
  else 
  {
    ModalText("<p>Vous ne voyez rien d'interressant !</p>")
  }
}

// ACTION = PRENDRE LA CLE SITUE DANS LE POT 5
function ActionTakeKeyInsideFlowerPot()
{
  ModalText("<p>Vous avez pris la clé située dans le pot 5. Vous pouvez voir sur la clé une étiquette où il y a écrit &laquo; PE &raquo;.</p>")
  e1_hasKeyFrontDoor = true;
  //Permet de cacher un bloc d'action 
  HideActionBloc('baE1_flowerPotKey');
}

// ACTION = PRENDRE L'ASTUCE SITUE SOUS LE DESSOUS DU POT 3
function ActionTakeHintBelowFlowerPot()
{
  ModalText("<p>Vous avez pris la note située sous le dessous du pot 3.</p>")
  e1_hasHintBelowFlowerPotThree = true;
  //Permet de cacher un bloc d'action 
  HideActionBloc('baE1_flowerPotHint');
}

// ACTION = DEPLACER LE TAPIS 
function ActionCarpetMove()
{
  //Permet d'indiquer que le tapis a était déplacer 
  e1_carpetMove = true;
  //Permet de retirer l'action de son bloc d'action et de le cache   
  AddRemoveClass('ba1FD_carpet',false,'baE1_frontDoor');
  EditIdDisplay('ba1FD_carpet', 'none');
  //Permet d'afficher un bloc d'action "Prendre clé sous tapis"
  DisplayActionBloc('baE1_carpetKey');
}

// ACTION = PRENDRE LA CLÉ SOUS LE TAPIS 
function ActionTakeKeyBelowCarpet()
{
  //Permet d'indiquer que la clé a était prise 
  e1_hasKeyMailbox = true;
  //Permet d'indiquer le nombre de clé posséder
  e1_numberOfKeyInInventory += 1;
  //Message 
  ModalText("<p>Vous avez pris la clé sous le tapis. Vous pouvez voir sur la clé une étiquette où il y a écrit &laquo; BAT &raquo;.</p>");
  //Permet de retirer l'action de son bloc d'origine et de le cacher  
  AddRemoveClass('ba1FDC_key',false,'baE1_carpetKey');
  EditIdDisplay('ba1FDC_key', 'none');
}

// ACTION = REMETTRE LE TAPIS EN PLACE
function ActionPutBackCarpet()
{
  //Permet d'indiquer que la tapis est à la place d'origine
  e1_carpetMove = false;
  //Permet de remettre une action dans son bloc d'origine et de l'afficher   
  AddRemoveClass('ba1FD_carpet',true,'baE1_frontDoor');
  EditIdDisplay('ba1FD_carpet', 'block');
  //Permet de cacher un bloc d'action
  HideActionBloc('baE1_carpetKey');
}

// ACTION = ALLER/RETOURNER VERS LA PORTE D'ENTREE
function ActionGoBackToFrontDoor()
{
  //Permet de changer l'image 
  ReplacePicture('inFrontOfHouse/frontDoor.jpg');
  //Permet de réinitialiser le choix des pots 
  e1_flowerPotThreeChosen = false;
  e1_flowerPotFiveChosen = false;
  //Permet de cacher un bloc d'action
  HideActionBloc('baE1_flowerPot');
  HideActionBloc('baE1_flowerPotKey');
  HideActionBloc('baE1_flowerPotHint');
  //Permet d'afficher un bloc d'action 
  DisplayActionBloc('baE1_frontDoor')
  //Permet d'afficher une alerte si condition
  if(e1_flowerPotPutDown == false)
  {
    //PAS SUR : Permet de cacher un bloc d'action
    HideActionBloc("baE1_flowerPotCarry");
    ModalText("<p>En repartant vous poser le pot par terre, à sa place.</p>");
    e1_flowerPotPutDown = true;
  }
  //Permet d'insérer une action dans son bloc d'origine
  AddRemoveClass("ba1FDFP_carryFlowerPot",true,"baE1_flowerPot");
  //Permet d'afficher le bloc d'action du tapis
  DisplayBlocActionCarpet()
}

// AFFICHAGE = PERMET DE CACHER LE BLOC D'ACTION DU TAPIS (QUITTER)
function HideBlocActionCarpet()
{
  //Permet de cacher un bloc d'action
  HideActionBloc('baE1_carpetKey'); 
}

// AFFICHAGE = PERMET D'AFFICHE LE BLOC D'ACTION DU TAPIS (DE RETOUR)
function DisplayBlocActionCarpet()
{
  if(e1_carpetMove == true)
  {
    //Permet d'afficher un bloc d'action
    DisplayActionBloc('baE1_carpetKey')
    //Permet de retirer l'action de son bloc d'action et de le cache   
    AddRemoveClass('ba1FD_carpet',false,'baE1_frontDoor');
    EditIdDisplay('ba1FD_carpet', 'none');
  }
  else
  {
    //Permet de remettre une action dans son bloc d'origine et de l'afficher   
    AddRemoveClass('ba1FD_carpet',true,'baE1_frontDoor');
    EditIdDisplay('ba1FD_carpet', 'block');
  }
}