/* ########################################################################## */
/*
  ###############################
  ## IN THE LOBBY OF THE HOUSE ##
  ###############################
*/
/* ########################################################################## */

/* ########################################################################## */

/*  
  ---------------
  ## VARIABLES ## 
  ---------------
*/  

/* ########################################################################## */

/*  
  ------------
  ## ONLOAD ## 
  ------------
*/  

function onloadLobbyHouse()
//document.onload = function() 
{
  //DisplayModalLogin();
  //lauchTimer();
  //let setRoom;
  sessionStorage.setItem("homeRoom","lobby")
  DisplayModalMission2Quete();
  let eRoomResolved = sessionStorage.getItem("Enigme2Resolved");
  let eFinalResolved = sessionStorage.getItem("EnigmeFinalResolved");
  if(eRoomResolved == "true")
  {
    //alert("ePiece")
    //let e2_wasResolved = true;
    AddRemoveClass('ba2GR_answerEnigmeRoom',false,'baE2_gardiensAnswer');
    EditIdDisplay('ba2GR_answerEnigmeRoom','none');
    //AddRemoveClass('ba2T_chest', false, "c_hide");
    //AddRemoveClass('ba2T_chest', true, "baE2_table");
    //EditIdDisplay("ba2T_chest", 'block');
    EditIdDisplay("txtE_GoalFinal", 'none');
    EditIdDisplay("txtE2_Goal01", 'none');
    EditIdDisplay("txtE_GoalFinal2", 'block');
  }
  else if(eFinalResolved == "true")
  {
    DisplayGameProgress(false,12)
    //alert("eFinal")
    //let eF_wasResolved = true;
    AddRemoveClass('ba2GR_answerEnigmeFinal',false,'baE2_gardiensAnswer')
    EditIdDisplay('ba2GR_answerEnigmeFinal','none')
  }
  else if(eRoomResolved == "true" && eFinalResolved == "true")
  {
    //alert("Vous avez finit le jeu")
    ModalText("Vous avez terminer tous les énigmes du jeu !");
  }
  else
  {
    console.log("Vous continuer l'histoire !")
    //alert("eNone")
    //let e2_wasResolved = false;
    //let eF_wasResolved = false;
  }
}

// DISPLAY MISSION - QUETE
function DisplayModalMission2Quete()
{
  let getModalContent = document.getElementById("modalMissionContent");
  let eRoomResolved = sessionStorage.getItem("Enigme2Resolved");
  let txt;
  eRoomResolved = eRoomResolved == "true" ? txt = "<li>Enigme final : Decoder le mot secret avec l'aide d'un document situé quelque part dans la pièce.</li>" : txt = "<li>Trouver le nom de votre prochaine destination.</li>"
  
  getModalContent.innerHTML = txt; 
  DisplayModalMission("Enigme n°2 - Quête", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon>Objectif</h2><p>Bonjour Héritié, je suis le fantôme gardant <em>l'entrée de la maison</em> si vous souhaitez sortir de cette pièce vous devez résoudre les énigmes suivantes :</p><ul>"+getModalContent.innerHTML+"</ul>","<bouton class='modal_button' onclick='DisplayModalMission2Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission2Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission2AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - RAPPEL
function DisplayModalMission2Rappel()
{
  DisplayModalMission("Enigme n°2 - Rappel", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Rappel</h2><ul><li>Pour obtenir vos énigmes, recherchez un fantôme (symbole <iconify-icon data-icon='la:ghost'></iconify-icon>), il y a au moins un fantôme par pièce.</li><li>Une fois chez le fantôme vous pouvez lui demander :</li><ul><li>Vos énigmes (symbole <iconify-icon data-icon='akar-icons:question'></iconify-icon>).</li> <li>Obtenir de l'aide (symbole <iconify-icon data-icon='akar-icons:info'></iconify-icon>).</li><li>Répondre à l'énigme (symbole <iconify-icon data-icon='ic:baseline-question-answer'></iconify-icon>).</li></ul></ul><ul><li>Pour décoder le mot secret, utilisez le document (<iconify-icon data-icon='cib:read-the-docs'></iconify-icon><iconify-icon data-icon='codicon:gist-secret'> </iconify-icon>) mis à disposition au sein de cette pièce.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission2Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission2Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission2AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - AIDE
function DisplayModalMission2AideGeneral()
{
  DisplayModalMission("Enigme n°2 - Aide", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Conseil(s)</h2><ul><li>Divers indices sont présents dans la pièce pour vous aider à découvrir l\'identité de la personnalité.</li><li>Vous pouvez venir nous voir en cliquant sur le symbole '<img src='../images/others/footprint.png' alt='Aller vers le fantôme' /><iconify-icon data-icon='la:ghost'></iconify-icon>', pour obtenir de l'aide.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission2Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission2Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission2AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}



/* ########################################################################## */

/*  
  -----------------------
  ## BAR ACTION DU BAS ## 
  -----------------------
*/

function HintGoalEnigme2(champ)
{
  ToggleHideAll('TextBlocGardiens');
  ToggleHideAll('TextBlocTable');
  if(champ == "goal")
  {
    ToggleDisplay('TextBlocDefault','txtE2_','1')
  }
  if(champ == "hint")
  {
    ToggleDisplay('TextBlocDefault','txtE2_','2');
  }
}
/* ########################################################################## */

/*  
  --------------------------------
  ## IN THE CENTRE OF THE LOBBY ## 
  --------------------------------
*/

// FUNCTION : ACTION WITH THE SWITCH
function ActionWithTheSwitch()
{
  sessionStorage.getItem("Enigme2Resolved") || "false";
  ModalText("<p>Alors que vous appuyez sur l’interrupteur, une voix, vous indique que c'est un moyen de déplacement en cours de réalisation. Vous ne pouvez malheureusement pas l'utiliser.</p>")
}

// ACTION GO TO GARIDENS 
function ActionGoToGardiens()
{
  ActionGoTo('hall/ghosts.jpg','baE2_lobby','baE2_gardiens')
  let getEnigme2Result = sessionStorage.getItem("Enigme2Resolved");
  let getEnigmeFinalResult = sessionStorage.getItem("EnigmeFinalResolved")
  if(getEnigme2Result == "true" && getEnigmeFinalResult == "true")
  {
    ModalText("Félicitation vous avez terminé tous les énigmes du jeu !")
  }
}

/* ########################################################################## */

/*  
  --------------
  ## GARDIENS ## 
  --------------
*/

// ACTION = RETOURNER VERS LE CENTRE
function ActionGoToGardiensToCenter()
{ 
  ToggleHideAll('TextBlocGardiens');
  ToggleHideAll('TextBlocDefault');
  HideActionBloc('baE2_gardiensAnswer');
  ActionGoTo('hall/hall2.jpg','baE2_gardiens','baE2_lobby')
}

// ACTION = INTERAGIR AVEC LES GARDIENS
function ActionInterragirGardiens(valeur)
{
  ToggleHideAll('TextBlocDefault');
  ToggleHideAll('TextBlocTable');
  if(valeur == "question")
  {
   DisplayModalInteractionAffichage('modalGardiens', 'modalGardiensTitle', 'modalGardiensContent', 'modalGardiensButtons', 'fermerModalGardiens',"Une question ?","Enigme pièce","enigme2piece","Enigme final","enigmefinal");
  }
  if (valeur == "aide")
  {
   DisplayModalInteractionAffichage('modalGardiens', 'modalGardiensTitle', 'modalGardiensContent', 'modalGardiensButtons', 'fermerModalGardiens',"Une info ?","Astuce","e2astuces","Indice","e2indices");
  }
  if (valeur == "repondre")
  {
    DisplayActionBloc('baE2_gardiensAnswer');
  }
}

// AFFICHAGE MODAL INTERAGIR AVEC LES GARDIENS
function DisplayModalInteractionRoom(createSection, contentOne, addContentOneId, contentTwo, addContentTwoId)
{
  if (addContentOneId == "enigme2piece")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p class="modal_text_center_to_justify">Énigme de la pièce :</p><ul><li>"Mon premier est un livre de référence fondamental souvent consulté. (Mon nom est inspiré par un mot grec)”.</li><li>"Mon second est le nom d\'un meuble qui permet de ce coucher généralement la nuit."</li><li>"Mon troisième est un corps liquide à la température et à la pression ordinaires, incolore, inodore, insipide, dont les molécules sont composées d\’un atome d’oxygène et de deux atomes d\’hydrogène.”</li><li>"Mon quatrième est un ensemble de disques constituants une collection.”</li><li>"Mon tout est le nom donné à l\'établissement destiné à recevoir une collection de livres ou documents"</li></ul>';
      EditIdDisplay('txtE2_HintDefault', 'none');
      EditIdDisplay('txtE_HintHelp', 'block');
    }
  }
  if (addContentTwoId == "enigmefinal")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Énigme final : &#128073; Découvrez le message final avec l\'aide du document "secret" trouvable sur la table.</p>';
      EditIdDisplay('txtE2_HintDefault', 'none');
      EditIdDisplay('txtE_HintFinalHelp', 'block');
      EditIdDisplay('txtE_HintHelp', 'block');
    }
  }
  if (addContentOneId == "e2astuces")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>&#128073; N\'hésitez pas à cliquer sur les divers boutons.</p><p>&#128073; Lisez bien les diverses énigmes.</p>'
    }
  }
  if (addContentTwoId == "e2indices")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>&#128073; Vous pouvez trouver des indices à la réponse de cette énigme sur la table</p><p> &#128073; Lisez bien les énigmes et les textes.</p>';
      EditIdDisplay('txtE_HintFinalHelp', 'block');
      EditIdDisplay('txtE_HintHelp', 'block');
      EditIdDisplay('txtE2_Hint01', 'block');
    }
  }
}

// ACTION = REPONDRE AUX GARDIENS
function ActionReplyToGardiens(valeur)
{
  if(valeur == "roomEnigme2")
  {
    let reponsePossible = ["Bibliothèque", "La Bibliothèque", "Biblio", "bibliothèque", "la bibliothèque", "biblio"];
    InputAnswer("text", valeur,"Quelle est la prochaine pièce ?",reponsePossible);
  }
  if(valeur == "finalEnigme")
  {
    let reponsePossible = ["covid-19","COVID-19"];
    InputAnswer("text", valeur,"Quelle est le mot secret ?",reponsePossible);
  }
}

// DISPLAY = CACHER LES BUTTONS DE REPONSE QUAND REPONDU
function HidePossibilityOfAnswerForEnigme2AndFinal(valeur)
{
  if(valeur == "roomEnigme2")
  {
    //Permet d'indiquer que vous avez répondu correctement
    e2_wasResolved = true;
    sessionStorage.setItem("Enigme2Resolved",e2_wasResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    RemoveElement('ba2GR_answerEnigmeRoom');
    HidePossibilityOfAnswerForEnigme2();
    ModalTextPage("Vous vous déplacez vers la porte....","library.html")
    //ChangePage('library.html',6000);
    SetPageLocalisation('library');
  }
  else if(valeur == "finalEnigme")
  {
    //Permet d'indiquer que vous avez répondu correctement
    eF_wasResolved = true;
    sessionStorage.setItem("EnigmeFinalResolved",eF_wasResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    RemoveElement('ba2GR_answerEnigmeFinal');
    //Texte
    ModalTextPage('<p>&laquo; Prenons cette crise (le confinement) comme une opportunité d\'un retour sur soi et bien sûr aussi d\'une plus grande attention à ses proches :<br />passer plus de temps avec sa famille, jouer et échanger avec ses enfants, parler au téléphone plus longuement avec ses amis sur les choses les plus essentielles de nos vies. &raquo; - Frédéric Lenoir.</p><p>Le porte est déverouillée vous pouvez maintenant sortir de la maison.</p><p>Mais dépéchez-vous de le faire !</p>',"outsideOfHouse.html");
    //ModalText('<p>&laquo; Prenons cette crise (le confinement) comme une opportunité d\'un retour sur soi et bien sûr aussi d\'une plus grande attention à ses proches :<br />passer plus de temps avec sa famille, jouer et échanger avec ses enfants, parler au téléphone plus longuement avec ses amis sur les choses les plus essentielles de nos vies. &raquo; - Frédéric Lenoir.</p><p>Le porte est déverouillé vous pouvez maintenant sortir de la maison.</p><p>Mais dépechez-vous de le faire !</p>');
    //ChangePage("outsideOfHouse.html",6000);
    SetPageLocalisation('outsideEnd');
    HidePossibilityOfAnswerForEnigme2();
  }
}

function HidePossibilityOfAnswerForEnigme2()
{
  let eFinalResolved = sessionStorage.getItem("EnigmeFinalResolved");
  let eRoomResolved = sessionStorage.getItem("Enigme2Resolved");
  //alert("enigme piece : " + sessionStorage.getItem("Enigme2Resolved"))
  //alert("enigme f : " + sessionStorage.getItem("EnigmeFinalResolved"))
  //if (eF_wasResolved == true && e2_wasResolved == true)
  if(eFinalResolved == "true" && eRoomResolved == "true")
  {
    AddRemoveClass("ba2G_answerEnigme", false, "baE2_gardiens");
    EditIdDisplay("ba2G_answerEnigme", "none");
  }
  //if(e2_wasResolved == true)
  if(eRoomResolved == "true" && eFinalResolved == "true")
  {
    ChangePage("outsideOfHouse.html",4000);
    SetPageLocalisation('outsideEnd');
  }
}

/* ########################################################################## */

/*  
  --------------
  ## LA TABLE ## 
  --------------
*/ 

// ACTION = RETOURNER VERS LA POSITION D'ORIGINE
function ActionGoToTableToCenter()
{
  ToggleHideAll('TextBlocDefault');
  ToggleHideAll('TextBlocTable');
  ActionGoTo('hall/hall2.jpg','baE2_table','baE2_lobby');
}

// ACTION = ALBUME PHOTO OUVRIR
function ActionPhotoAlbum() 
{
 document.getElementById("modalAlbumPhotoA").style.display = "block";
 slideIndex = 1;
 showSlide(slideIndex,'slideA');
}

// ACTION = ALBUME PHOTO FERMER
function ClosePhotoAlbum()
{
  document.getElementById("modalAlbumPhotoA").style.display = "none";
}

// ACTION = LIRE A PAPIER
function ActionPaper(type)
{
  ToggleHideAll('TextBlocDefault');
  ToggleHideAll('TextBlocGardiens');
  if(type == "hint")
  {
    //Affiche une liste de nom de bibliothèques
    ToggleDisplay('TextBlocTable','txtE2_Table_','1');
  }
  if(type == "own")
  {
    //Affiche une liste de nom de livre
    ToggleDisplay('TextBlocTable','txtE2_Table_','2');
  }
  if(type == "write")
  {
    //Affiche une définition de bibliothèque & de livre
    ToggleDisplay('TextBlocTable','txtE2_Table_','3');
  }
  if(type == "game")
  {
    //Affiche une petite explication sur le jeu 
    ToggleDisplay('TextBlocTable','txtE2_Table_','4');
  }
  if(type == "code")
  {
    //Affiche le documenet permettant de déchiffrer/découvrir le message final.
    ToggleDisplay('TextBlocTable','txtE2_Table_','5')
  }
}

// ACTION = FERMER LE MESSAGE SECRET
function FermerTableMessage()
{
  document.getElementById("modalMessageSecret").style.display = "none";
}