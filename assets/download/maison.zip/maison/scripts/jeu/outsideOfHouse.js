function onloadGameEnd()
{
  ModalText("<p>Fin du jeu - Félicitations ! Vous avez trouvé le bon mot secret.</p>");
  changeImageAuto2();
  displayResultTimer();
}

function changeImageAuto2()
{
  setTimeout(function() {ReplacePicture("end/roomasylum.jpg")}, 10000);
}

function displayResultTimer()
{
  let getMinutes = sessionStorage.getItem("timerMinute");
  let getSecondes = sessionStorage.getItem("timerSeconde");

  let minutesSpent = 59 - getMinutes;
  let secondsSpent = 60 - getSecondes;

  if (minutesSpent < 10)
  {
    minutesSpent = "0" + minutesSpent;
  }
  if (secondsSpent < 10)
  {
    secondsSpent = "0" + secondsSpent;
  }

  let txt = document.getElementById("resultTimer")
  txt.innerHTML = "<p>Vous avez résolus les énigmes en " + minutesSpent+" minutes et "+secondsSpent+" secondes.</p>"
}