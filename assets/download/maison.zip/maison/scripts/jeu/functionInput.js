/* ########################################################################## */
/*
  << INPUT & CHECK >>
*/
/* ########################################################################## */

/* ########################################################################## */

// MODIFIER LES PROPRIETES DE LA FONCTION POUR POUVOIR MODIFIER LE "areaInput.type"

function InputAnswer(type, nom, texte, liste)
{
  let areaTitle = document.getElementById('modalTextInputTitle');
  areaTitle.innerHTML = texte;

  let areaText = document.getElementById('modalTextInputText');
  let areaInput = document.createElement('input');
  areaInput.type = type;
  areaInput.id = nom;
  areaText.appendChild(areaInput);
  
  let areaButtons = document.getElementById('modalTextInputButtons');
  areaButtons.style.display = "flex";

  let buttonContinue = document.createElement('button');
  buttonContinue.innerHTML = "Valider";
  buttonContinue.classList.add("modal_button");
  buttonContinue.id = "modalInputButtonCancel"
  areaButtons.appendChild(buttonContinue);

  let buttonCancel = document.createElement('button');
  buttonCancel.innerHTML = "Annuler";
  buttonCancel.classList.add("modal_button");
  buttonCancel.id = "modalInputButtonCancel"
  areaButtons.appendChild(buttonCancel);

  let modal = document.getElementById('modalTextInput');
  modal.style.display = "block";

  let reponse = "";

  buttonContinue.onclick = function()
  {
    HideModalInput(areaTitle, areaInput, areaButtons, buttonContinue, buttonCancel, modal, reponse=areaInput.value)
    CheckAnswer(nom, liste, reponse);
  };
  
  areaInput.addEventListener("keypress", function(event)
  {
    if (event.key == 13 || event.keyCode == 13 || event.code == 13) 
    {
      event.preventDefault();
      HideModalInput(areaTitle, areaInput, areaButtons, buttonContinue, buttonCancel, modal, reponse=areaInput.value)
      CheckAnswer(nom, liste, reponse);
    }
  });

  buttonCancel.onclick = function()
  {
    HideModalInput(areaTitle, areaInput, areaButtons, buttonContinue, buttonCancel, modal, reponse=areaInput.value)
    CheckAnswer(nom, liste, reponse);
  }

  window.onclick = function(event) 
  {
    if (event.target == modal) 
    {
      HideModalInput(areaTitle, areaInput, areaButtons, buttonContinue, buttonCancel, modal, reponse=areaInput.value)
      CheckAnswer(nom, liste, reponse);
    }
  }
}

function  HideModalInput(areaTitle, areaInput, areaButtons, buttonContinue, buttonCancel, modal, reponse=areaInput.value)
{
  areaTitle.innerHTML = ""; 
  areaInput.remove(); 
  areaButtons.style.display = "none";
  buttonContinue.remove(); 
  buttonCancel.remove(); 
  modal.style.display = "none";
  reponse = reponse;
}
/* ---------------------------------------- */
//Permet de vérifier les réponses
function CheckAnswer(nom, liste, reponse)
{
  if(liste.indexOf(reponse) >= 0)
  {
    DisplayAnswer(nom, true)
  }
  else if (reponse == null || reponse == "")
  {
    DisplayAnswer(nom, null)
  }
  else 
  {
    DisplayAnswer(nom, false)
  }
}
/* ---------------------------------------- */
//Permet d'afficher les réponses
function DisplayAnswer(nom, valeur)
{
  if(valeur == true)
  {
    ModalText("<p>Félicitations ! Vous avez trouvé la bonne réponse !</p>");
    if(nom == 'roomEnigme2')
    {
      HidePossibilityOfAnswerForEnigme2AndFinal("roomEnigme2");
    }
    if(nom == 'finalEnigme')
    {
      HidePossibilityOfAnswerForEnigme2AndFinal("finalEnigme");
    }
    if(nom == "characterEnigme3")
    {
      HidePossibiltyOfAnswerForEnigmeThree("characterEnigme3");
    }
    if(nom == "roomEnigme3")
    {
      HidePossibiltyOfAnswerForEnigmeThree('roomEnigme3');
    }
    if(nom == "characterEnigme4")
    {
      HidePossibiltyOfAnswerForEnigmeFour("characterEnigme4");
    }
    if(nom == "roomEnigme4")
    {
      HidePossibiltyOfAnswerForEnigmeFour('roomEnigme4');
    }
    if(nom == "characterEnigme5")
    {
      HidePossibiltyOfAnswerForEnigmeFive("characterEnigme5");
    }
    if(nom == "roomEnigme5")
    {
      HidePossibiltyOfAnswerForEnigmeFive('roomEnigme5');
    }
    if(nom == "characterAEnigme6")
    {
      HidePossibiltyOfAnswerForEnigmeSix('characterAEnigme6');
    }
    if(nom == "characterBEnigme6")
    {
      HidePossibiltyOfAnswerForEnigmeSix('characterBEnigme6');
    }
    if(nom == "characterCEnigme6")
    {
      HidePossibiltyOfAnswerForEnigmeSix('characterCEnigme6');
    }
    if(nom == "roomEnigme6")
    {
      HidePossibiltyOfAnswerForEnigmeSix('roomEnigme6');
    }
  }
  else if(valeur == false)
  {
    ModalText("<p>Dommage ! C'est une mauvaise réponse !<br />Continuer à chercher et à lire les textes.</p>");
  }
  else if(valeur == null)
  {
    ModalText("<p>Votre réponse a été annulée ! Vous êtes trop loin du fantôme ! Retentez votre chance !</p>");
  }
  else 
  {
    alert("ERREUR : Function AffichageReponse()" + "type : " + nom + " valeur : " + valeur)
  }
}