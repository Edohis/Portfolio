/* ########################################################################## */
/*
  << INVENTORY >>
*/
/* ########################################################################## */

/* ########################################################################## */

// FUNCTION = DISPLAY INVENTORY
function DisplayInventory(classe, nom, data)
{
  let show = document.getElementById(nom + data);
  if (show.classList.contains("c_visible"))
  {
    show.classList.remove("c_visible");
    show.classList.add("c_hide");
    show.style.display = "none";
  }
  else
  {
    if (show.classList.contains("c_hide"))
    {
      show.classList.remove("c_hide")
    }
    show.classList.add("c_visible");
    show.style.display = "flex";
  }
  HideInventory(classe, data);
}

// FUNCTION = HIDE INVENTORY
function HideInventory(classe, data)
{
  let list = document.getElementsByClassName(classe);
  for (let i = 0, len = list.length; i < len; i++)
  {
    if (i != data - 1)
    {
      list[i].classList.remove('c_visible');
      list[i].classList.add("c_hide");
      list[i].style.display = "none";
    }
  }
}