//Permet de créer des "sliders"
function SlideNext(valeur, classe)
{
  showSlide(slideIndex +=valeur,classe);
}

function showSlide(valeur, classe)
{
  let x = document.getElementsByClassName(classe);
  if (valeur > x.length) {slideIndex = 1}
  if (valeur < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block"; 
}