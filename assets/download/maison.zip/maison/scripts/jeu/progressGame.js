function DisplayGameProgress()
{
  let numberTotal = 11;
  
  let number = sessionStorage.getItem("gameProgressNumber") || 0;
  let enigme = sessionStorage.getItem("gameProgressEnigme") || 0;
  //alert("1 = " + number + " - " + enigme);
  
  let eRoomResolved = sessionStorage.getItem("Enigme2Resolved");
  let e02 = sessionStorage.getItem("e02Check") || "false";
  if(eRoomResolved == "true" && e02 != "true")
  {
    //alert("hall r")
    e02 = sessionStorage.setItem("e02Check","true")
    number++;
    enigme++;
  }
  
  let e3RoomResolved = sessionStorage.getItem("Enigme3RoomResolved");
  let e3CharacterResolved = sessionStorage.getItem("Enigme3CharacterResolved");
  let e03 = sessionStorage.getItem("e03check") || "false";
  if(e3RoomResolved == "true" && e03 != "true")
  {
    //alert("lib r")
    number++
  }
  if(e3CharacterResolved == "true" && e03 != "true")
  {
    //alert("lib c")
    number++ 
  }
  if(e3CharacterResolved == "true" && e3RoomResolved == "true" && e03 != "true")
  {
    //alert("lib r c")
    e03 = sessionStorage.setItem("e03check","true")
    enigme++;
  }
  
  let e4RoomResolved = sessionStorage.getItem("Enigme4RoomResolved");
  let e4CharacterResolved = sessionStorage.getItem("Enigme4CharacterResolved");
  let e04 = sessionStorage.getItem("e04check") || "false";
  if(e4RoomResolved == "true" && e04 != "true")
  {
    //alert("bedroom r");
    number++;
  }
  if(e4CharacterResolved == "true" && e04 != "true")
  {
    //alert("bedroom c");
    number++;
  }
  if(e4CharacterResolved == "true" && e4RoomResolved == "true" && e04 != "true")
  {
    //alert("bedroom c r");
    e04 = sessionStorage.setItem("e04check","true");
    enigme++;
  }
  
  let e5RoomResolved = sessionStorage.getItem("Enigme5RoomResolved");
  let e5CharacterResolved = sessionStorage.getItem("Enigme5CharacterResolved");
  let e05 = sessionStorage.getItem("e05check") || "false";
  if(e5RoomResolved == "true" && e05 != "true")
  {
    //alert("galery r");
    number++;
  }
  if(e5CharacterResolved == "true" && e05 != "true")
  {
    //alert("galery c");
    number++;
  }
  if(e5CharacterResolved == "true" && e5RoomResolved == "true" && e05 != "true")
  {
    //alert("galery c r");
    e05 = sessionStorage.setItem("e05check","true");
    enigme++;
  }

  let e6RoomResolved = sessionStorage.getItem("Enigme6RoomResolved");
  let e6CharacterAResolved = sessionStorage.getItem("Enigme6CharacterAResolved");
  let e6CharacterBResolved = sessionStorage.getItem("Enigme6CharacterBResolved");
  let e6CharacterCResolved = sessionStorage.getItem("Enigme6CharacterCResolved");
  let e06 = sessionStorage.getItem("e06check") || "false";
  if(e6RoomResolved == "true" && e06 != "true")
  {
    //alert("workshop r");
    number++;
    enigme++;
  }
  if(e6CharacterAResolved == "true" && e06 != "true")
  {
    //alert("workshop ca");
    number++;
    enigme++;
  }
  if(e6CharacterBResolved == "true" && e06 != "true")
  {
    //alert("workshop cb");
    number++;
    enigme++;
  }
  if(e6CharacterCResolved == "true" && e06 != "true")
  {
    //alert("workshop cc");
    number++;
    enigme++;
  }
  if(e6CharacterAResolved == "true" && e6CharacterBResolved == "true" && e6CharacterCResolved == "true" && e6RoomResolved == "true"  && e06 != "true")
  {
    //alert("workshop r ca cb cc");
    e06 = sessionStorage.setItem("e06check","true");
  }
  
  sessionStorage.setItem("gameProgressNumber",number);
  sessionStorage.setItem("gameProgressEnigme",enigme);
  //alert("2 = " + number + " - " + enigme);
  
  number = sessionStorage.getItem("gameProgressNumber");
  enigme = sessionStorage.getItem("gameProgressEnigme");
  //alert("3 = " + number + " - " + enigme);
  
  let progress = (number/numberTotal)*100;
  progress = Math.round(progress);
  let txt = document.getElementById("gameProgress");
  txt.innerHTML = "<p>Progression des énigmes : " + progress + "%" + "</p>";
  txt.innerHTML += "<p>Nombre d'indices récupérer pour l'énigme finale : " + enigme + "/8</p>";
}

// PROGRESS DETAILS
function DisplayModalProgressMore()
{
  //alert("WSH")
  // GET : ID 
  let content = document.getElementById("modalGameProgressContent");
  // GET : SESSION STORAGE 
  let eRoomResolved = sessionStorage.getItem("Enigme2Resolved");
  let eFinalResolved = sessionStorage.getItem("EnigmeFinalResolved");
  let e3RoomResolved = sessionStorage.getItem("Enigme3RoomResolved");
  let e3CharacterResolved = sessionStorage.getItem("Enigme3CharacterResolved");
  let e4RoomResolved = sessionStorage.getItem("Enigme4RoomResolved");
  let e4CharacterResolved = sessionStorage.getItem("Enigme4CharacterResolved");
  let e5RoomResolved = sessionStorage.getItem("Enigme5RoomResolved");
  let e5CharacterResolved = sessionStorage.getItem("Enigme5CharacterResolved");
  let e6RoomResolved = sessionStorage.getItem("Enigme6RoomResolved");
  let e6CharacterAResolved = sessionStorage.getItem("Enigme6CharacterAResolved");
  let e6CharacterBResolved = sessionStorage.getItem("Enigme6CharacterBResolved");
  let e6CharacterCResolved = sessionStorage.getItem("Enigme6CharacterCResolved");
  // DECLARE 
  let iconRoom,tagLiOpen,tagLiClose,txtSolved,txtNoSolved;
  let txtE02R,txtEF,txtE03C,txtE03R,txtE04C,txtE04R,txtE05C,txtE05R,txtE06CA,txtE06CB,txtE06CC,txtE06R;
  // SET VARIABLE TEXT 
  iconRoom = "<iconify-icon data-icon='ic:sharp-room'></iconify-icon>";
  tagLiOpen = "<li>";
  tagLiClose = "</li>";
  tagLiOpenResolved = "<li class='enigmeDone'>";
  txtSolved = "<em>Résolu</em>";
  txtNoSolved = "<em>A résoudre</em>";
  // SET VALUE TEXT
    // FOR ENIGME 2 
  eRoomResolved = eRoomResolved == "true" ? txtE02R = tagLiOpenResolved+"Enigme de la pièce : "+txtSolved+tagLiClose : txtE02R = tagLiOpen+"Enigme de la pièce : "+txtNoSolved+tagLiClose;
    // FOR ENIGME FINAL 
  eFinalResolved = eFinalResolved == "true" ? txtEF = tagLiOpenResolved+"Enigme finale : "+txtSolved+tagLiClose : txtEF = tagLiOpen+"Enigme finale : "+txtNoSolved+tagLiClose;
    // FOR ENIGME 3
      // CHARACTER
  e3CharacterResolved = e3CharacterResolved == "true" ? txtE03C = tagLiOpenResolved+"Enigme de la personnalité : "+txtSolved+tagLiClose : txtE03C = tagLiOpen+"Enigme de la personnalité : "+txtNoSolved+tagLiClose;
      // ROOM
  e3RoomResolved = e3RoomResolved == "true" ? txtE03R = tagLiOpenResolved+"Enigme de la pièce : "+txtSolved+tagLiClose : txtE03R = tagLiOpen+"Enigme de la pièce : "+txtNoSolved+tagLiClose;
    // FOR ENIGME 4
      // CHARACTER
  e4CharacterResolved = e4CharacterResolved == "true" ? txtE04C = tagLiOpenResolved+"Enigme de la personnalité : "+txtSolved+tagLiClose : txtE04C = tagLiOpen+"Enigme de la personnalité : "+txtNoSolved+tagLiClose;
      // ROOM
  e4RoomResolved = e4RoomResolved == "true" ? txtE04R = tagLiOpenResolved+"Enigme de la pièce : "+txtSolved+tagLiClose : txtE04R = tagLiOpen+"Enigme de la pièce : "+txtNoSolved+tagLiClose;
    // FOR ENIGME 5
      // CHARACTER
  e5CharacterResolved = e5CharacterResolved == "true" ? txtE05C = tagLiOpenResolved+"Enigme de la personnalité : "+txtSolved+tagLiClose : txtE05C = tagLiOpen+"Enigme de la personnalité : "+txtNoSolved+tagLiClose;
      // ROOM
  e5RoomResolved = e5RoomResolved == "true" ? txtE05R = tagLiOpenResolved+"Enigme de la pièce : "+txtSolved+tagLiClose : txtE05R = tagLiOpen+"Enigme de la pièce : "+txtNoSolved+tagLiClose;
    // FOR ENIGME 6
      // CHARACTER 1
  e6CharacterAResolved = e6CharacterAResolved == "true" ? txtE06CA = tagLiOpenResolved+"Enigme de la personnalité A : "+txtSolved+tagLiClose : txtE06CA = tagLiOpen+"Enigme de la personnalité : "+txtNoSolved+tagLiClose;
      // CHARACTER 2
  e6CharacterBResolved = e6CharacterBResolved == "true" ? txtE06CB = tagLiOpenResolved+"Enigme de la personnalité B : "+txtSolved+tagLiClose : txtE06CB = tagLiOpen+"Enigme de la personnalité : "+txtNoSolved+tagLiClose;
      // CHARACTER 3
  e6CharacterCResolved = e6CharacterCResolved == "true" ? txtE06CC = tagLiOpenResolved+"Enigme de la personnalité C : "+txtSolved+tagLiClose : txtE06CC = tagLiOpen+"Enigme de la personnalité : "+txtNoSolved+tagLiClose;
      // ROOM
  e6RoomResolved = e6RoomResolved == "true" ? txtE06R = tagLiOpenResolved+"Enigme de la pièce : "+txtSolved+tagLiClose : txtE06R = tagLiOpen+"Enigme de la pièce : "+txtNoSolved+tagLiClose;
  // SET RESULT TEXT 
  content.innerHTML = "<ul>"+tagLiOpen+iconRoom+"Entrée"+tagLiClose+"<ul>"+txtE02R+txtEF+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Bibliothèque"+tagLiClose+"<ul>"+txtE03C+txtE03R+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Chambre"+tagLiClose+"<ul>"+txtE04C+txtE04R+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Galerie"+tagLiClose+"<ul>"+txtE05C+txtE05R+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Atelier"+tagLiClose+"<ul>"+txtE06CA+txtE06CB+txtE06CC+txtE06R+"</ul></ul>";
  // DISPLAY TEXT
  DisplayModalGameProgress("Progression des énigmes",content.innerHTML,"<bouton class='modal_button' onclick='ModalGameProgressClose()'>Cacher</bouton><bouton class='modal_button' onclick='ModalGameProgressAndInventoryEnigmeClose()'>Ferme</bouton>");
}

// PROGRESS GIFT
function DisplayModalProgressGift()
{
  //alert("WSH")
  // GET : ID 
  let content = document.getElementById("modalGameProgressContent");
  // GET : SESSION STORAGE 
  let eRoomResolved = sessionStorage.getItem("Enigme2Resolved");
  let eFinalResolved = sessionStorage.getItem("EnigmeFinalResolved");
  let e3RoomResolved = sessionStorage.getItem("Enigme3RoomResolved");
  let e3CharacterResolved = sessionStorage.getItem("Enigme3CharacterResolved");
  let e4RoomResolved = sessionStorage.getItem("Enigme4RoomResolved");
  let e4CharacterResolved = sessionStorage.getItem("Enigme4CharacterResolved");
  let e5RoomResolved = sessionStorage.getItem("Enigme5RoomResolved");
  let e5CharacterResolved = sessionStorage.getItem("Enigme5CharacterResolved");
  let e6RoomResolved = sessionStorage.getItem("Enigme6RoomResolved");
  let e6CharacterAResolved = sessionStorage.getItem("Enigme6CharacterAResolved");
  let e6CharacterBResolved = sessionStorage.getItem("Enigme6CharacterBResolved");
  let e6CharacterCResolved = sessionStorage.getItem("Enigme6CharacterCResolved");
  // DECLARE 
  let iconRoom,tagLiOpen,tagLiClose,txtSolved,txtNoSolved,txtMsg,taber;
  let txtE02andF,txtE03,txtE04,txtE05,txtE06,txtE06CA,txtE06CB,txtE06CC;
  // SET VARIABLE TEXT 
  iconRoom = "<iconify-icon data-icon='ic:sharp-room'></iconify-icon>";
  tagLiOpen = "<li>";
  tagLiClose = "</li>";
  txtMsg = "Mon indice secret est : ";
  //tagLiOpenResolved = "<li class='enigmeDone'>";
  tagLiOpenResolved = "<li style='color:";
  txtNoSolvedR = "<em>La pièce n'a pas été découverte</em>";
  txtNoSolvedSR = "<em>La sous pièce n'a pas été découverte</em>";
  tagNoSolvedR = tagLiOpen+txtNoSolvedR+tagLiClose;
  tagNoSolvedSR = tagLiOpen+txtNoSolvedSR+tagLiClose;
  // SET VALUE TEXT
    // FOR ROOM "HALL"
  if(eRoomResolved == "true")
  {
    txtE02andF = tagLiOpenResolved+"#C0C000;'>"+txtMsg+"15"+tagLiClose;
  }
  else
  {
    txtE02andF = tagNoSolvedR;
  }
    // FOR ROOM "LIBRARY"
  if(e3RoomResolved == "true" && e3CharacterResolved == "true")
  {
    txtE03 = tagLiOpenResolved+"#b26666;'>"+txtMsg+"36"+tagLiClose;
  }
  else 
  {
    txtE03 = tagNoSolvedR;
  }
    // FOR ROOM "BEDROOM";
  if(e4RoomResolved == "true" && e4CharacterResolved == "true")
  {
    txtE04 = tagLiOpenResolved+"#C080C0;'>"+txtMsg+"28"+tagLiClose;
  }
  else 
  {
    txtE04 = tagNoSolvedR;
  }
    // FOR ROOM "GALERY"
  if(e5RoomResolved == "true" && e5CharacterResolved == "true")
  {
    txtE05 = tagLiOpenResolved+"#408040;'>"+txtMsg+"3"+tagLiClose;
  }
  else 
  {
    txtE05 = tagNoSolvedR;
  }
    // FOR ROOM "WORKSHOP";
  if(e6CharacterAResolved == "true")
  {
    txtE06CA = tagLiOpenResolved+"#80FF80;'>"+txtMsg+"27"+tagLiClose;
  }
  else 
  {
    txtE06CA = tagNoSolvedSR;
  }
  if(e6CharacterBResolved == "true")
  {
    txtE06CB = tagLiOpenResolved+"#FF8080;'>"+txtMsg+"19"+tagLiClose;
  }
  else 
  {
    txtE06CB = tagNoSolvedSR;
  }
  if(e6CharacterCResolved == "true")
  {
    txtE06CC = tagLiOpenResolved+"#40C0C0;'>"+txtMsg+"26"+tagLiClose;
  }
  else 
  {
    txtE06CC = tagNoSolvedSR;
  }
  if(e6RoomResolved == "true")
  {
    txtE06 = tagLiOpenResolved+"#4040C0;'>"+txtMsg+"17"+tagLiClose;
  }
  else
  {
    txtE06 = tagNoSolvedR;
  }
  
  taber = "<span class='indiceCase4'>?</span><span class='indiceCase7'>?</span><span class='indiceCase1'>?</span><span class='indiceCase6'>?</span><span class='indiceCase2'>?</span><span class='indiceCase3'>?</span><span class='indiceCase5'>?</span><span class='indiceCase8'>?</span>"
  // SET RESULT TEXT 
  content.innerHTML = "<ul style='margin-top:10px'>"+tagLiOpen+"Code : "+taber+tagLiClose+"</ul>"+"<br />"+"<ul>"+tagLiOpen+iconRoom+"Entrée"+tagLiClose+"<ul>"+txtE02andF+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Bibliothèque"+tagLiClose+"<ul>"+txtE03+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Chambre"+tagLiClose+"<ul>"+txtE04+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Galerie"+tagLiClose+"<ul>"+txtE05+"</ul></ul>"+"<ul>"+tagLiOpen+iconRoom+"Atelier"+tagLiClose+"<ul>"+txtE06CA+txtE06CB+txtE06CC+txtE06+"</ul></ul>";
  // DISPLAY TEXT
  DisplayModalGameProgress("Progression des énigmes",content.innerHTML,"<bouton class='modal_button' onclick='ModalGameProgressClose()'>Cacher</bouton><bouton class='modal_button' onclick='ModalGameProgressAndInventoryEnigmeClose()'>Ferme</bouton>");
}