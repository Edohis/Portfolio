// FUNCTION = DISPLAY MODAL START TIMER 
function DisplayModalStartTimer(style)
{
  let modal = document.getElementById("modalStartTimer");
  modal.style.display = style;
  startTimer();
}

function StartTimerGame()
{
  sessionStorage.setItem("startTimer", "demarrer");
  DisplayModalStartTimer("none");
}