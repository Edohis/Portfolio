TableLigne('divTB','1','G','2','Q','3','C');
TableLigne('divTB','4','R','5','J','6','L');
TableLigne('divTB','7','B','8','Y','9','A');
TableLigne('divTB','10','N','11','K','12','T');
TableLigne('divTB','13','S','14','X','15','V',);
TableLigne('divTB','16','M','17','O','18','E');
TableLigne('divTB','19','D','20','W','21','U',);
TableLigne('divTB','22','P','23','H','24','F');
TableLigne('divTB','25','Z','26','I','27','1');
TableLigne('divTB','28','9','29','6','30','8');
TableLigne('divTB','31','7','32','2','33','4');
TableLigne('divTB','34','5','35','3','36','-');
  
function TableLigne(value,c1,c2,c3,c4,c5,c6)
{
  let divTB = document.getElementById(value);
  let divTR = document.createElement("div");
  divTR.classList.add("divTableRow");
  divTB.appendChild(divTR);
  
  let divCellA = document.createElement("div");
  divCellA.classList.add("divTableCell");
  divCellA.innerHTML = c1;
  divTR.appendChild(divCellA);
  
  let divCellB = document.createElement("div");
  divCellB.classList.add("divTableCell");
  divCellB.innerHTML = c2;
  divTR.appendChild(divCellB);
  
  let divCellC = document.createElement("div");
  divCellC.classList.add("divTableCell");
  divCellC.innerHTML = c3;
  divTR.appendChild(divCellC);
  
  let divCellD = document.createElement("div");
  divCellD.classList.add("divTableCell");
  divCellD.innerHTML = c4;
  divTR.appendChild(divCellD);
  
  let divCellE = document.createElement("div");
  divCellE.classList.add("divTableCell");
  divCellE.innerHTML = c5;
  divTR.appendChild(divCellE);
  
  let divCellF = document.createElement("div");
  divCellF.classList.add("divTableCell");
  divCellF.innerHTML = c6;
  divTR.appendChild(divCellF);
}