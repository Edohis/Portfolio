/* ########################################################################## */
/*
  << SCRIPT - INTRODUCTION >>
*/
/* ########################################################################## */

/* ########################################################################## */

function ActionSearchOldLetter()
{
  //bouton
  ShowContent("btn_readOldLetter");
  HideContent("btn_searchOldLetter");
  //texte 
  ShowContent("txt_searchOldLetter");
  HideContent("txt_start")
}