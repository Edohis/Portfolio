/* ########################################################################## */
/*
  #################################
  ## IN THE BEDROOM OF THE HOUSE ##
  #################################
*/
/* ########################################################################## */


/* ########################################################################## */

/*  
  ---------------
  ## VARIABLES ## 
  ---------------
*/

let e4_wasResolved = false;
let e4_characterResolved = false;
let e4_roomResolved = false;
let e4_chestOpen = false;
let e4_knowsSpellToOpenChest = false;
let e4_knowsSpellToOpenChestMessage = false;
let e4_spellBookOpen = false;

/* ########################################################################## */

/*  
  ------------
  ## ONLOAD ## 
  ------------
*/  

function onloadBedroom()
//document.onload = function() 
{
  //DisplayModalLogin();
  //lauchTimer();
  let setRoom = sessionStorage.setItem("homeRoom","bedroom")
  DisplayModalMission4Quete();
  let e4RoomResolved = sessionStorage.getItem("Enigme4RoomResolved");
  let e4CharacterResolved = sessionStorage.getItem("Enigme4CharacterResolved");
}

// DISPLAY MISSION - QUETE
function DisplayModalMission4Quete()
{
  DisplayModalMission("Enigme n°4 - Quête", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon>Objectif</h2><p>Bonjour, <strong>Héritié</strong>, je suis le fantôme gardant <em>la chambre de la maison</em> si vous souhaitez sortir de cette pièce, vous devez résoudre les énigmes suivantes :</p><ul><li>Trouver le nom de votre prochaine destination.</li><li>Trouver le moyen d'ouvrir le coffre magique pour obtenir le code.</li><li>Trouver l'identité de la personnalité de cette pièce.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission4Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission4Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission4AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}
// DISPLAY MISSION - RAPPEL
function DisplayModalMission4Rappel()
{
  DisplayModalMission("Enigme n°4 - Rappel", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Rappel</h2><ul><li>Pour obtenir vos énigmes, recherchez un fantôme (symbole <iconify-icon data-icon='la:ghost'></iconify-icon>), il y a au moins un fantôme par pièce.</li><li>Une fois chez le fantôme, vous pouvez lui demander :</li><ul><li>L'énigmes (symbole <iconify-icon data-icon='akar-icons:question'></iconify-icon>).</li> <li>Obtenir de l'aide (symbole <iconify-icon data-icon='akar-icons:info'></iconify-icon>).</li><li>Répondre l'énigme (symbole <iconify-icon data-icon='ic:baseline-question-answer'></iconify-icon>).</li></ul></ul>","<bouton class='modal_button' onclick='DisplayModalMission4Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission4Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission4AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - AIDE
function DisplayModalMission4AideGeneral()
{
  DisplayModalMission("Enigme n°4 - Aide", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Conseil(s)</h2><ul><li>Divers indices sont présents dans la pièce pour vous aider à découvrir l'identité de la personnalité.</li><li>Une liste de sorts est présente dans la pièce pour vous aider à découvrir le sort.</li><li>Vous pouvez venir nous voir en cliquant sur le symbole &laquo;	<img src='../images/others/footprint.png' alt='Aller vers le fantôme' /><iconify-icon data-icon='la:ghost'></iconify-icon> &raquo;, pour obtenir de l'aide.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission4Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission4Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission4AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

/* ########################################################################## */

/*  
  -----------------------
  ## BAR ACTION DU BAS ## 
  -----------------------
*/

function HintGoalEnigme4(champ)
{
  ToggleHideAll('TextBlocGhost');
  if (champ == "goal")
  {
    ToggleDisplay('TextBlocDefault', 'txtE4_', '1')
  }
  if (champ == "hint")
  {
    ToggleDisplay('TextBlocDefault', 'txtE4_', '2');
  }
}
/* ########################################################################## */

/*  
  ----------------------------------
  ## IN THE CENTRE OF THE LIBRARY ## 
  ----------------------------------
*/

// ACTION WITH THE CHEST 
function ActionWithChest()
{
  if(e4_knowsSpellToOpenChestMessage == true)
  {
    ModalText("<p>Vous utilisez le sort magique que vous avez découvert dans la pièce et réussissez à déverrouiller le coffre magique.</p>");
    e4_knowsSpellToOpenChestMessage = false;
  }
  if(e4_chestOpen == false)
  {
    ActionWithChestDefault();
  }
  if(e4_chestOpen == true)
  {
    ActionWithChestOpenIt();
  }
}

function ActionWithChestDefault()
{
  let txt;
  if(e4_knowsSpellToOpenChest == true)
  {
    txt = "Un coffre magique déverrouillé ouvrable.";
  }
  else 
  { 
    txt = "Un coffre magique verrouillé, mais dévérouillable avec le bon sort magique.";
  }
  DisplayModalTextAction("Le Coffre Magique",txt,"<bouton class='modal_button' onclick='ActionWithChestOpenIt()'>Ouvrir</bouton><bouton class='modal_button' onclick='ActionWithChestQuit()'>Quitter</bouton>");
  e4_chestOpen = false;
}

function ActionWithChestQuit()
{
  document.getElementById("modalTextAction").style.display = "none";
}

function ActionWithChestOpenIt()
{
  if(e4_knowsSpellToOpenChest == true)
  {
    DisplayModalTextAction("Le Coffre Magique","<h3 style='text-align:left'>Indice pour le code de l'énigme :</h3><ul><li>Pour trouver le code vous devez trouver le résultat de chaque question affichée ci-dessous :</li><ol><li>Mon résultat est le nombre de lettre dans \"Harry Potter\"</li><li>Mon résultat est le nombre de sorts magiques affichés dans le livre des sorts.</li><li>Mon résultat est l'addition du résultat de la question 1 à celui de la question 2.</li><li>Mon résultat est la soustraction du résultat de la question 1 à celui de la question 2.</li></ol></ul><ul><li>Ps: L'ordre du code est le suivant : 2-4-1-3.</li></ul>","<bouton class='modal_button' onclick='ActionWithChestDefault()'>Fermer</bouton><bouton class='modal_button' onclick='ActionWithChestQuit()'>Quitter</bouton>");
    e4_chestOpen = true;
  }
  else
  {
    ModalText("<p>Vous tentez d'ouvrir le coffre magique, mais sans succès. Vous devez connaître le sort magique ouvrant le coffre ! Il se trouve dans la pièce.</p>")
    e4_chestOpen = false;
  }
}

// ACTION WITH THE JACKET
function ActionWithJacket()
{
  if(e4_knowsSpellToOpenChest == false)
  {
    ModalText('<p>C\'est une veste de magicien inspirée de la série <em>Harry Potter</em>.<br />En la fouillant, vous trouvez un papier où il est écrit : &laquo;	Aperipectustuum - Dévérouille &raquo;	</p>');
    e4_knowsSpellToOpenChest = true;
    e4_knowsSpellToOpenChestMessage = true;
  }
  else
  {
    ModalText('<p>Une veste de magicien inspirée de la série <em>Harry Potter</em>.</p>');
  }
}

// ACTION WITH THE SPELL BOOKS
function ActionWithSpellBooks()
{
  if(e4_spellBookOpen == false)
  {
    ActionWithSpellBooksDefault()
  }
  else
  {
    ActionWithSpellBooksPage4()
  }
}

function ActionWithSpellBooksDefault()
{
  DisplayModalTextAction("Livre des sorts","Un livre intitulé <em>&laquo;	Sorts magiques - Tout est possible &raquo;</em> avec divers dessins et textes dont : <em>&laquo; Ces sorts fonctionnent-ils ? Peut-on devenir invincible ? immortel ? Ce qu'on veut... &laquo;</em><br />Vous pouvez également voir un bookmaker sur une des pages..</p>","<bouton class='modal_button' onclick='ActionWithSpellBooksPage4()'>Aller à la page du bookmaker</bouton><bouton class='modal_button' onclick='ActionWithSpellBooksQuit()'>Quitter</bouton>");
  e4_spellBookOpen = false;
}

function ActionWithSpellBooksPage4()
{
  DisplayModalTextAction("Livre des sorts (Page 4)","<ol><li>Accio : Permet d'attirer l'élément ciblé.</li><li>Allohomora : Permet d'ouvrir une porte verrouillée.</li><li>Crac badaboum : Permet de casser l'élément ciblé.</li><li>Recurvite : Permet de nettoyer l'élément ciblé.</li><li>Rictuscempra : Permet de renverser l'élément ciblé.</li><li>Apparescere : Permet de faire apparaître l'élément souhaité.</li><li>Confringo : Permet de détruire l'élément souhaité.</li><li>Sonoratium : Permet de générer un bruit sonore.</li</ol>","<bouton class='modal_button' onclick='ActionWithSpellBooksDefault()'>Fermer</bouton><bouton class='modal_button' onclick='ActionWithSpellBooksQuit()'>Quitter</bouton>");
  e4_spellBookOpen = true;
}

function ActionWithSpellBooksQuit()
{
  document.getElementById("modalTextAction").style.display = "none";
}

/* ########################################################################## */

/*
  -----------
  ## GHOST ## 
  -----------
*/

// ACTION = RETOURNER A LA PLACE D'ORIGINE
function ActionGoToGhostToRoom()
{
 ToggleHideAll('TextBlocDefault'); 
 ToggleHideAll('TextBlocGhost');
 HideActionBloc("baE4_ghostAnswer");
 ActionGoTo('bedroom/bedroom.jpg','baE4_ghost','baE4_bedroom');
}

// ACTION = INTERAGIR AVEC LES GARDIENS
function ActionInterragirGhost(valeur)
{
  ToggleHideAll('TextBlocDefault');
  if (valeur == "question")
  {
    DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Une question ?", "Enigme pièce", "enigme4piece", "Enigme personnalité", "enigme4personnage");
  }
  if (valeur == "aide")
  {
    DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Une info ?", "Astuce", "e4astuces", "Indice", "e4indices");
  }
  if (valeur == "repondre")
  {
    DisplayActionBloc('baE4_ghostAnswer');
  }
}

// AFFICHAGE MODAL INTERAGIR AVEC LES GARDIENS
function DisplayModalInteractionRoom(createSection, contentOne, addContentOneId, contentTwo, addContentTwoId)
{
  if (addContentOneId == "enigme4piece")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>Voici votre énigme de la pièce :<br />Quel est le code que vous avez trouvé dans le coffre magique ?</p>'
    }
  }
  if (addContentTwoId == "enigme4personnage")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Énigme - Qui suis-je ? :<br />Je suis née en 1965 en juillet. Je suis anglaise (britannique). Je suis romancière et scénariste.</p><p>Ma notoriété mondiale est en partie due à une des mes oeuvres, une série de roman sur les aventures d\'un jeune sorcier,</p><p>qui a était traduit en près de quatre-vingts langues et vendu à plus de 500 millions d\'exemplaires dans le monde.</p>';
      EditIdDisplay('txtE4_Hint02','block');
    }
  }
  if (addContentOneId == "e4astuces")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>Généralement, le thème de la pièce est un gros indice pour la réponse d\'au moins une des énigmes présentes dans chaque pièce de la maison.</p>';
    }
  }
  if (addContentTwoId == "e4indices")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Il y a divers sorts magiques disposés au sein de cette pièce.</p>';
      EditIdDisplay('txtE4_Hint01','block');
    }
  }
}

// ACTION = REPONDRE A UN ENIGME (FANTOME)
function ActionReplyToGhost(valeur)
{
  if(valeur == "characterEnigme4") // ENIGME : QUI SUIS-JE
  {
    let reponsePossible = ["J.K. Rowling","j.k rowling", "J K rowling", "j k rowling","Robert Galbraith", "robert galbraith","Joanne Rowling", "joanne rowling"]; //Les diverses possibilité d'écrire le prénom;
    InputAnswer("text", valeur, "Quelle est l'identité (prénom & nom) de la personnalité ?",reponsePossible);
  }
  if(valeur == "roomEnigme4") // ENIGME : DONNER LE CODE TROUVER
  {
    let reponsePossible = ["831119"]; //Uniquement un code possible 
    InputAnswer("number", valeur, "Quelle est le code à six chiffre ?",reponsePossible);
  }
}

// DISPLAY = CACHER LES BUTTONS DE REPONSE QUAND REPONDU
function HidePossibiltyOfAnswerForEnigmeFour(valeur)
{
  if(valeur == "characterEnigme4")
  {
    //Permet d'indiquer que vous avez répondu correctement
    e4_characterResolved = true;
    let e4CharacterResolved = sessionStorage.setItem("Enigme4CharacterResolved",e4_characterResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    AddRemoveClass('ba4GR_answerEnigmeCharacter',false,'baE4_ghostAnswer'); 
    EditIdDisplay('ba4GR_answerEnigmeCharacter','none');
  }
  if(valeur == "roomEnigme4")
  {
    //Permet d'indiquer que vous avez répondu correctement
    e4_roomResolved = true;
    let e4RoomResolved = sessionStorage.setItem("Enigme4RoomResolved",e4_roomResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    AddRemoveClass('ba4GR_answerEnigmeRoom',false,'baE4_ghostAnswer');
    EditIdDisplay('ba4GR_answerEnigmeRoom','none');
  }
  if(e4_characterResolved == true && e4_roomResolved == true)
  {
    e4_wasResolved = true;
  }
  HidePossibilityOfAnswerForEnigme4()
}

function HidePossibilityOfAnswerForEnigme4()
{
  if (e4_wasResolved == true)
  {
    AddRemoveClass("ba4G_answerEnigme", false, "baE4_ghost");
    EditIdDisplay("ba4G_answerEnigme", "none");
    ModalTextPage("Vous vous déplacez vers la porte....","galery.html")
    //ChangePage("galery.html",6000);
    SetPageLocalisation('galery');
  }
}