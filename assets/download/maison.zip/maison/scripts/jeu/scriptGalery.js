/* ########################################################################## */
/*
  ###############################
  ## IN THE GALERY OF THE HOUSE ##
  ###############################
*/
/* ########################################################################## */

/* ########################################################################## */

/*  
  ---------------
  ## VARIABLES ## 
  ---------------
*/  

let e5_wasResolved = false;
let e5_characterResolved = false;
let e5_roomResolved = false;
let e5_discoveredPaperInsideTrashCan = false;
let e5_hasPaperInTrashCan = false;

/* ########################################################################## */

/*  
  ------------
  ## ONLOAD ## 
  ------------
*/  

function onloadGalery()
//document.onload = function() 
{
  //DisplayModalLogin();
  //lauchTimer();
  sessionStorage.setItem("homeRoom","galery")
  DisplayModalMission5Quete();
  sessionStorage.getItem("Enigme5RoomResolved");
  sessionStorage.getItem("Enigme5CharacterResolved");
}

// DISPLAY MISSION - QUETE
function DisplayModalMission5Quete()
{
  DisplayModalMission("Enigme n°5 - Quête", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon>Objectif</h2><p>Bonjour, <strong>Hérité</strong>, je suis le fantôme gardant <em>la galerie de la maison</em> si vous souhaitez sortir de cette pièce, vous devez résoudre les énigmes suivantes :</p><ul><li>Trouver le nom de votre prochaine destination.</li><li>Trouver le code en répondant aux questions de l'énigme.</li><li>Trouver l'identité de la personnalité de cette pièce.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission5Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission5Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission5AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - RAPPEL
function DisplayModalMission5Rappel()
{
  DisplayModalMission("Enigme n°5 - Rappel", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Rappel</h2><ul><li>Pour obtenir vos énigmes recherchées un fantôme (symbole <iconify-icon data-icon='la:ghost'></iconify-icon>), il y a au moins un fantôme par pièce.</li><li>Une fois chez le fantôme, vous pouvez lui demander :</li><ul><li>Vos énigmes (symbole <iconify-icon data-icon='akar-icons:question'></iconify-icon>).</li> <li>Obtenir de l'aide (symbole <iconify-icon data-icon='akar-icons:info'></iconify-icon>).</li><li>Répondre à l'énigme (symbole <iconify-icon data-icon='ic:baseline-question-answer'></iconify-icon>).</li></ul></ul>","<bouton class='modal_button' onclick='DisplayModalMission5Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission5Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission5AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - AIDE
function DisplayModalMission5AideGeneral()
{
  DisplayModalMission("Enigme n°5 - Aide", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Conseil(s)</h2><ul><li>Divers indices indiquant votre prochaine destination sont présents dans la pièce.</li><li>Divers indices sont présents dans la pièce pour vous aider à découvrir l'identité de la personnalité :</li><li>Lisez bien les diverses informations données.</li><li>Vous pouvez venir nous voir en cliquant sur le symbole <em>&laquo; <img src='../images/others/footprint.png' alt='Aller vers le fantôme' /><iconify-icon data-icon='la:ghost'></iconify-icon> &raquo;</em>, pour obtenir de l'aide.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission5Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission5Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission5AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

/* ########################################################################## */

/*  
  -----------------------
  ## BAR ACTION DU BAS ## 
  -----------------------
*/

function HintGoalEnigme5(champ)
{
  ToggleHideAll('TextBlocGhost');
  if(champ == "goal")
  {
    ToggleDisplay('TextBlocDefault','txtE5_','1')
  }
  if(champ == "hint")
  {
    ToggleDisplay('TextBlocDefault','txtE5_','2');
  }
}

/* ########################################################################## */

/*  
  ------------
  ## GALERY ## 
  ------------
*/


/* ########################################################################## */

/*  
  ---------------
  ## TRASH CAN ## 
  ---------------
*/

// ACTION = LOOK INSIDE TRASH CAN
function ActionLookInsideTrashCan()
{
  if(e5_discoveredPaperInsideTrashCan == false)
  {
    ModalText('<p>En regardant dans la poubelle, vous pouvez voir un papier en boule où quelque chose semble être écrit.</p>');
    e5_discoveredPaperInsideTrashCan = true;
  }
  else
  {
    if(e5_hasPaperInTrashCan == false)
    {
      ModalText('<p>Le papier est toujours à la même place.');
    }
    //else
    //{
      //ModalText("<p>Divers déchets. Rien d'important !</p>");
    //}
  }
  //Permet d'afficher une action
  if(e5_discoveredPaperInsideTrashCan == true && e5_hasPaperInTrashCan == false)
  {
    AddRemoveClass('ba5TC_takePaperTrashCan',false, 'baE5_trashCanPaper');
    AddRemoveClass('ba5TC_takePaperTrashCan',true, 'baE5_trashCan');
    EditIdDisplay('ba5TC_takePaperTrashCan','block');
  }
}

// ACTION = TAKE CODE INSIDE TRASH CAN
function ActionTakePaperTrashCan()
{
  ModalText('<p>Vous pouvez lire sur la papier qu\'il y aurait un problème de fonctionnement dans la pièce <em>d\'atelier de la maison</em>.</p>');
  //AddRemoveClass('ba5TC_takePaperTrashCan', false,'baE5_trashCan');
  //AddRemoveClass('ba5TC_takePaperTrashCan', true,'baE5_trashCanPaper');
  //EditIdDisplay('ba5TC_takePaperTrashCan','none');
  //e5_hasPaperInTrashCan = true;
}

/* ########################################################################## */

/*
  -----------
  ## GHOST ## 
  -----------
*/

// ACTION = RETOURNER A LA PLACE D'ORIGINE
function ActionGoToGhostToRoom()
{
 ToggleHideAll('TextBlocDefault'); 
 ToggleHideAll('TextBlocGhost');
 HideActionBloc("baE5_ghostAnswer");
 ActionGoTo('galery/galerie.jpg','baE5_ghost','baE5_galery');
}


// ACTION = INTERAGIR AVEC LES GARDIENS
function ActionInterragirGhost(valeur)
{
  ToggleHideAll('TextBlocDefault');
  if (valeur == "question")
  {
    DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Une question ?", "Enigme pièce", "enigme5piece", "Enigme personnalité", "enigme5personnage");
  }
  if (valeur == "aide")
  {
    DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Une info ?", "Astuce", "e5astuces", "Indice", "e5indices");
  }
  if (valeur == "repondre")
  {
    DisplayActionBloc('baE5_ghostAnswer');
  }
}

// AFFICHAGE MODAL INTERAGIR AVEC LES GARDIENS
function DisplayModalInteractionRoom(createSection, contentOne, addContentOneId, contentTwo, addContentTwoId)
{
  if (addContentOneId == "enigme5piece")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p class="modal_text_center_to_justify">Énigme de la pièce : Quel le code trouvé selon les réponses ci-dessous ?</p><ol><li>"Mon résultat correspond au nombre de tableaux (blanc) présent dans la pièce."</li><li>"Mon résultat est le nombre d\'indice donné pour l\'énigme de la personnalité."</li><li>"Mon résultat est le nombre de chiffre dans la valeur PI suivante : \"3.141592653\"."</li><li>"Mon résultat est le nombre de peinture disponible dans cette pièce dont l\'auteur est \"Pablo Piccasso\"."</li><li>"Mon résultat est le nombre de peinture disponible dans cette pièce dont l\'auteur est \"Léonard de Vinci\"."</li><li>"Mon résultat est le résultat de l\'équation suivante : \"8+2-4+6\"."</li></ol><p class="modal_text_center_to_justify">PS : La disposition du code selon les questions est la suivante : \"3-4-2-6-5-1\"."</p>'
    }
  }
  if (addContentTwoId == "enigme5personnage")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p class="modal_text_center_to_justify">Énigme - Qui suis-je ?</p><ol><li>"Mon premier est le prénom d\'un célèbre trafiquant colombien de cocaine, dans les années 1980."</li><li>"Mon second est le nom donnée à la valeur irrationnelle suivante : \"3.141592653\"."</li><li>"Mon troisième est un mot en trois lettres signifiant une possibilité."</li><li>"Mon quatrième est le nom de la formule chimique du monoxyde de souffre."</li><li>"Mon tout est un artiste espagnole et fondateur du cubisme."</li></ol>'
      EditIdDisplay('txtE4_Hint02','block');
    }
  }
  if (addContentOneId == "e5astuces")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>Généralement, le thème de la pièce est un gros indice pour la réponse d\'au moins une des énigmes présentes dans chaque pièce de la maison.</p>';
    }
  }
  if (addContentTwoId == "e5indices")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>L\'identité de la personnalité est citée dans l\'énigme de la pièce.</p>';
      EditIdDisplay('txtE4_Hint01','block');
    }
  }
}


// ACTION = REPONDRE A UN ENIGME (FANTOME)
function ActionReplyToGhost(valeur)
{
  if(valeur == "characterEnigme5") // ENIGME : QUI SUIS-JE
  {
    let reponsePossible = ["Pablo Picasso", "pablo picasso", "Pablo Ruiz Picasso", "pablo ruiz picasso", "PABLO PICASSO", "PABLO RUIZ PICASSO"]; //Les diverses possibilité d'écrire le prénom;
    InputAnswer("text", valeur, "Quelle est l'identité (prénom & nom) de la personnalité ?",reponsePossible);
  }
  if(valeur == "roomEnigme5") // ENIGME : DONNER LE CODE TROUVER
  {
    let reponsePossible = ["101512210"]; //Uniquement un code possible 
    InputAnswer("number", valeur, "Quel est le code à neuf chiffres ?",reponsePossible);
  }
}

// DISPLAY = CACHER LES BUTTONS DE REPONSE QUAND REPONDU
function HidePossibiltyOfAnswerForEnigmeFive(valeur)
{
  if(valeur == "characterEnigme5")
  {
    //Permet d'indiquer que vous avez répondu correctement
    let e5_characterResolved = true;
    sessionStorage.setItem("Enigme5CharacterResolved",e5_characterResolved)
    //Permet de retirer l'action de son bloc d'action et de le cacher
    AddRemoveClass('ba5GR_answerEnigmeCharacter',false,'baE5_ghostAnswer'); 
    EditIdDisplay('ba5GR_answerEnigmeCharacter','none');
  }
  if(valeur == "roomEnigme5")
  {
    //Permet d'indiquer que vous avez répondu correctement
    let e5_roomResolved = true;
    sessionStorage.setItem("Enigme5RoomResolved",e5_roomResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    AddRemoveClass('ba5GR_answerEnigmeRoom',false,'baE5_ghostAnswer');
    EditIdDisplay('ba5GR_answerEnigmeRoom','none');
  }
  let e5CharacterResolved = sessionStorage.getItem("Enigme5CharacterResolved");
  let e5RoomResolved = sessionStorage.getItem("Enigme5RoomResolved");
  if(e5CharacterResolved == "true" && e5RoomResolved == "true")
  {
    e5_wasResolved = true;
  }
  HidePossibilityOfAnswerForEnigme5()
}

function HidePossibilityOfAnswerForEnigme5()
{
  if (e5_wasResolved == true)
  {
    AddRemoveClass("ba5G_answerEnigme", false, "baE5_ghost");
    EditIdDisplay("ba5G_answerEnigme", "none");
    ModalTextPage("Vous vous déplacez vers la porte....","workshop.html")
    //ChangePage("workshop.html",6000);
    SetPageLocalisation('workshop');
  }
}