let heure,minute,seconde;

function displayTextTimer()
{
  let getMinute = sessionStorage.getItem("timerMinute") || "59";
  let getSeconde = sessionStorage.getItem("timerSeconde") || "60";
  let textTimer = document.getElementById('timer');
  textTimer.innerHTML = "<iconify-icon data-icon='ic-round-timer'></iconify-icon> 00" + ":" + getMinute + ":" + getSeconde;
  
  let textTimer2 = document.getElementById('timer2');
  textTimer2.innerHTML = "<iconify-icon data-icon='ic-round-timer'></iconify-icon> 00" + ":" + getMinute + ":" + getSeconde + " - PAUSE"
}

function startTimer()
{
  let stopTime = false;
  sessionStorage.setItem("timerStopTime",stopTime);
  setTimer(60,00);
}

function stopTimer()
{
  let stopTime = sessionStorage.getItem("timerStopTime"); 
  if(stopTime == "false")
  {
    stopTime = true;
    stopTime = sessionStorage.setItem("timerStopTime",stopTime);
    stopTime = sessionStorage.getItem("timerStopTime"); 
    displayTimer();
  }
}

function lauchTimer() 
{
  let stopTime = sessionStorage.getItem("timerStopTime");
  if(stopTime == "true")
  {
    stopTime = false;
    stopTime = sessionStorage.setItem("timerStopTime",stopTime);
    let m = sessionStorage.getItem("timerMinute");
    let s = sessionStorage.getItem("timerSeconde");
    setTimer(m,s)
  }
}

function setTimer(minutes, secondes)
{
  minute = minutes;
  seconde = secondes;
  displayTextTimer()
  displayTimer();
}

function displayTimer()
{
  let stopTime = sessionStorage.getItem("timerStopTime")
  if(stopTime == "false")
  {
    let timerGame = setInterval(function() {LoopTimer()},1000);
    sessionStorage.setItem("timerGameInterval", timerGame)
  }

  else if(stopTime == "true")
  {
    let getTimerGameInterval = sessionStorage.getItem("timerGameInterval")
    clearInterval(getTimerGameInterval);
  }
}

function LoopTimer()
{
  minute = parseInt(minute);
  seconde = parseInt(seconde);
  seconde = seconde - 1;
  if (seconde < 0)
  {
    seconde = 0;
  }
  if (seconde == 0 && minute != 0)
  {
    minute = minute - 1;
    seconde = 59;
  }
  if (seconde < 10)
  {
    seconde = '0' + seconde;
  }
  if (minute < 10)
  {
    minute = '0' + minute;
  }
  if (minute == "00" && seconde == "00")
  {
    seconde == "00";
    let stopTime = true;
    stopTime = sessionStorage.setItem("timerStopTime", stopTime);
    let getTimerGameInterval = sessionStorage.getItem("timerGameInterval")
    clearInterval(getTimerGameInterval);
    endTimer();
  }
  sessionStorage.setItem("timerMinute", minute);
  sessionStorage.setItem("timerSeconde", seconde);
  displayTextTimer();
}

function endTimer()
{
  ModalText("<h3>Perdu !</h3><p>Fin de la partie, vous n'avez pas reussi à vous échapper avant la fin du temps !</p>")
  sessionStorage.setItem("resultGamePage","true")
  ChangePage("resultGame.html");
}

function NewGame()
{
  sessionStorage.clear();
  ModalTextPage("<h3>Recommencer</h3><p>Vous allez commencer une nouvelle partie dans quelques secondes ! </p>","index.html");
  //ChangePage("index.html");
}