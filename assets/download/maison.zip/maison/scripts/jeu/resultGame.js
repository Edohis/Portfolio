/* ########################################################################## */
/*
  ###############
  ## GAME OVER ##
  ###############
*/
/* ########################################################################## */

/* ########################################################################## */

function onloadResultGame()
{
  let setRoom = sessionStorage.getItem("homeRoom");
  //alert(setRoom);
  if(setRoom == "outside" || setRoom == "none")
  {
    ReplacePicture("inFrontOfHouse/infrontofhouse.jpg");
  }
  if(setRoom == "lobbyBefore")
  {
    ReplacePicture("hall/hall.jpg");
  }
  if(setRoom == "lobby" || setRoom == "lobby2Before")
  {
    ReplacePicture("hall/hall2.jpg");
  }
  if(setRoom == "library")
  {
    ReplacePicture("library/library.jpg");
  }
  if(setRoom == "bedroom")
  {
    ReplacePicture("bedroom/bedroom.jpg");
  }
  if(setRoom == "galery")
  {
    ReplacePicture("galery/galerie.jpg");
  }
  if(setRoom == "workshop")
  {
    ReplacePicture("workshop/workshop.jpg");
  }
  changeImageAuto();
}

function changeImageAuto()
{
  setTimeout(function() {ReplacePicture("end/white.jpg")}, 10000);
}