/* ########################################################################## */
/*
  ###############################
  ## IN THE LOBBY OF THE HOUSE ##
  ###############################
*/
/* ########################################################################## */

/* ########################################################################## */

/*  
  ---------------
  ## VARIABLES ## 
  ---------------
*/  

let e3_wasResolved = false;
let e3_discoveredCodeInsideTrashCan = false; 
let e3_hasCodeInTrashCan = false;
let e3_characterResolved = false;
let e3_roomResolved = false;

/* ########################################################################## */

/*  
  ------------
  ## ONLOAD ## 
  ------------
*/  

function onloadLibrary()
//document.onload = function() 
{
  //DisplayModalLogin();
  //lauchTimer();
  sessionStorage.setItem("homeRoom","library")
  DisplayModalMission3Quete();
  sessionStorage.getItem("Enigme3RoomResolved");
  sessionStorage.getItem("Enigme3CharacterResolved");
}

// DISPLAY MISSION - QUETE
function DisplayModalMission3Quete()
{
  DisplayModalMission("Enigme n°3 - Quête", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon>Objectif</h2><p>Bonjour, <strong>Hérité</strong>, je suis le fantôme gardant <em>la bibliothèque de la maison</em> si vous souhaitez sortir de cette pièce, vous devez résoudre les énigmes suivantes :</p><ul><li>Trouver le nom de votre prochaine destination.</li><li>Trouver le code à 4 chiffres.</li><li>Trouver l'identité de la personnalité de cette pièce.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission3Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission3Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission3AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - RAPPEL
function DisplayModalMission3Rappel()
{
  DisplayModalMission("Enigme n°3 - Rappel", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Rappel</h2><ul><li>Pour obtenir vos énigmes recherchées un fantôme (symbole <iconify-icon data-icon='la:ghost'></iconify-icon>), il y a au moins un fantôme par pièce.</li><li>Une fois chez le fantôme, vous pouvez lui demander :</li><ul><li>Vos énigmes (symbole <iconify-icon data-icon='akar-icons:question'></iconify-icon>).</li> <li>Obtenir de l'aide (symbole <iconify-icon data-icon='akar-icons:info'></iconify-icon>).</li><li>Répondre à l'énigme (symbole <iconify-icon data-icon='ic:baseline-question-answer'></iconify-icon>).</li></ul></ul>","<bouton class='modal_button' onclick='DisplayModalMission3Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission3Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission3AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

// DISPLAY MISSION - AIDE
function DisplayModalMission3AideGeneral()
{
  DisplayModalMission("Enigme n°3 - Aide", "<h2 class='modal_text_title'><iconify-icon data-icon='vaadin:diploma-scroll'></iconify-icon> Conseil(s)</h2><ul><li>Divers indices sont présents dans la pièce pour vous aider à découvrir l'identité de la personnalité.</li><li>Une liste de sorts est présente dans la pièce pour vous aider à découvrir le sort.</li><li>Vous pouvez venir nous voir en cliquant sur le symbole &laquo;	<img src='../images/others/footprint.png' alt='Aller vers le fantôme' /><iconify-icon data-icon='la:ghost'></iconify-icon> &raquo;, pour obtenir de l'aide.</li></ul>","<bouton class='modal_button' onclick='DisplayModalMission3Quete()'>Quête</bouton><bouton class='modal_button' onclick='DisplayModalMission3Rappel()'>Rappel</bouton><bouton class='modal_button' onclick='DisplayModalMission3AideGeneral()'>Aide général</bouton><bouton class='modal_button' onclick='ModalMissionClose()'>Fermer</bouton>");
}

/* ########################################################################## */

/*  
  -----------------------
  ## BAR ACTION DU BAS ## 
  -----------------------
*/

function HintGoalEnigme3(champ)
{
  ToggleHideAll('TextBlocGhost');
  if(champ == "goal")
  {
    ToggleDisplay('TextBlocDefault','txtE3_','1')
  }
  if(champ == "hint")
  {
    ToggleDisplay('TextBlocDefault','txtE3_','2');
  }
}

/* ########################################################################## */

/*  
  ----------------------------------
  ## IN THE CENTRE OF THE LIBRARY ## 
  ----------------------------------
*/

// FUNCTION = ALLER A LA PORTE DE LA PIECE
function ActionGoToFrontDoorOfRoom()
{
  if(e3_wasResolved == true )
  {
    EditIdDisplay('btn_goToBedroom','block');
  }
  else
  {
    ModalText('<p>Vous tentez d\'ouvrir la porte, sans succès. Une voix vous indique que vous devez résoudre les énigmes de la pièce pour progresser.</p>');
  }
}

// FUNCTION : DISPLAY TEXT FOR SHELVES
function DisplayTextForShelf(shelf)
{
  if(shelf == "shelfA")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont ceux de Molière.</p>');
  }
  else if(shelf == "shelfC")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont ceux d\'Émile Zola.</p>');
  }
  else if(shelf == "shelfD")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont un livre de Victor Hugo, \'Les Misérables\'.</p>');
  }
  else if(shelf == "shelfE")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont ceux de Victor Hugo et de Voltaire.</p>');
  }
  else if(shelf == "shelfF")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont un livre intitulé \'Cosette ou le temps des illusions\'.</p>');
  }
  else if(shelf == "shelfG")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont ceux d\'Alexandre Dumas.</p>');
  }
  else if(shelf == "shelfH")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont ceux de Jean-Jascques Rousseau.</p>');
  }
  else
  {
    ModalText('<p>Une étagère avec divers collections de livres.</p>');
  }
} 
/* ########################################################################## */

/*
  ---------------
  ## TRASH CAN ## 
  ---------------
*/

// ACTION = LOOK INSIDE TRASH CAN
function ActionLookInsideTrashCan()
{
  if(e3_discoveredCodeInsideTrashCan == false)
  {
    ModalText('<p>En regardant dans la poubelle, vous pouvez voir un papier avec un code inscrit dessus.</p>');
    e3_discoveredCodeInsideTrashCan = true;
  }
  else
  {
    if(e3_hasCodeInTrashCan == false)
    {
      ModalText('<p>Le papier est toujours à la même place.');
    }
    //else
    //{
      //ModalText("<p>Divers déchets. Rien d'important !</p>");
    //}
  }
  //Permet d'afficher une action
  if(e3_discoveredCodeInsideTrashCan == true && e3_hasCodeInTrashCan == false)
  {
    AddRemoveClass('ba3TC_takeCodeTrashCan',false, 'baE3_trashCanCode');
    AddRemoveClass('ba3TC_takeCodeTrashCan',true, 'baE3_trashCan');
    EditIdDisplay('ba3TC_takeCodeTrashCan','block');
  }
}

// ACTION = TAKE CODE INSIDE TRASH CAN
function ActionTakeCodeTrashCan()
{
  ModalText('<p>Vous pouvez lire sur le papier le code suivant : "Code : - 8 - - "</p>');
  //AddRemoveClass('ba3TC_takeCodeTrashCan', false,'baE3_trashCan');
  //AddRemoveClass('ba3TC_takeCodeTrashCan', true,'baE3_trashCanCode');
  //EditIdDisplay('ba3TC_takeCodeTrashCan','none');
  //e3_hasCodeInTrashCan = true;
}
 
/* ########################################################################## */

/*
  -----------
  ## GHOST ## 
  -----------
*/

// ACTION = RETOURNER A LA PLACE D'ORIGINE
function ActionGoToGhostToRoom()
{
 ToggleHideAll('TextBlocDefault'); 
 ToggleHideAll('TextBlocGhost');
 HideActionBloc("baE3_ghostAnswer");
 ActionGoTo('library/library.jpg','baE3_ghost','baE3_mainRoom');
}

//

// ACTION = INTERAGIR AVEC LES GARDIENS
function ActionInterragirGhost(valeur)
{
  ToggleHideAll('TextBlocDefault');
  if (valeur == "question")
  {
    DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Une question ?", "Enigme pièce", "enigme3piece", "Enigme personnalité", "enigme3personnage");
  }
  if (valeur == "aide")
  {
    DisplayModalInteractionAffichage('modalGhost', 'modalGhostTitle', 'modalGhostContent', 'modalGhostButtons', 'fermerModalGhost', "Une info ?", "Astuce", "e3astuces", "Indice", "e3indices");
  }
  if (valeur == "repondre")
  {
    DisplayActionBloc('baE3_ghostAnswer');
  }
}

// AFFICHAGE MODAL INTERAGIR AVEC LES GARDIENS
function DisplayModalInteractionRoom(createSection, contentOne, addContentOneId, contentTwo, addContentTwoId)
{
  if (addContentOneId == "enigme3piece")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>Énigme de la pièce : Vous devez me donner le code à quatre chiffres que vous pouvez découvrir en interagissant avec les divers éléments présents dans cette pièce.</p>';
    }
  }
  if (addContentTwoId == "enigme3personnage")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Énigme - Qui suis-je ?<br />Je suis né en 1802 en février. Je suis français. Je suis poète, dramaturge, écrivain, romancier et dessinateur. Une des mes oeuvres fait référance à un célèbre monument français dont le nom s’inspire d’un titre attribué autrefois à la femme d’un seigneur mais qui est également le nom d’un arrêt de métro à Paris qui est associé au nom de la capitale de la France. L’autre met en avant des personnes pauvres. Qui suis-je ?</p>'
    }
  }
  if (addContentOneId == "e3astuces")
  {
    contentOne.onclick = function()
    {
      createSection.innerHTML = '<p>Lisez les textes & cliquez sur les divers boutons</p>';
    }
  }
  if (addContentTwoId == "e3indices")
  {
    contentTwo.onclick = function()
    {
      createSection.innerHTML = '<p>Le code est composé de quatre chiffres. Il y a donc quatre papiers à trouver.</p><p>Des informations de la personnalité sont présentes dans la pièce</p><p>Des indices pour la prochaine pièce sont également présents dans la pièce.</p>';
    }
  }
}

// ACTION = REPONDRE A UN ENIGME (FANTOME)
function ActionReplyToGhost(valeur)
{
  if(valeur == "characterEnigme3") // ENIGME : QUI SUIS-JE
  {
    let reponsePossible = ["Victor Hugo","VICTOR HUGO", "victor hugo", "Victor-Marie Hugo", "Victor Marie Hugo", "VICTOR-MARIE HUGO", "VICTOR MARIE HUGO", "victor-marie hugo", "victor marie hugo"]; //Les diverses possibilité d'écrire le prénom;
    InputAnswer("text", valeur, "Quelle est l'identité (prénom & nom) de la personnalité ?",reponsePossible);
  }
  if(valeur == "roomEnigme3") // ENIGME : DONNER LE CODE TROUVER
  {
    let reponsePossible = ["1802"]; //Uniquement un code possible 
    InputAnswer("number", valeur, "Quelle est le code à quatre chiffre ?",reponsePossible);
  }
}

// DISPLAY = CACHER LES BUTTONS DE REPONSE QUAND REPONDU
function HidePossibiltyOfAnswerForEnigmeThree(valeur)
{
  if(valeur == "characterEnigme3")
  {
    //Permet d'indiquer que vous avez répondu correctement
    e3_characterResolved = true;
    let e3CharacterResolved = sessionStorage.setItem("Enigme3CharacterResolved",e3_characterResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    AddRemoveClass('ba3GR_answerEnigmeCharacter',false,'baE3_ghostAnswer'); 
    EditIdDisplay('ba3GR_answerEnigmeCharacter','none');
  }
  if(valeur == "roomEnigme3")
  {
    //Permet d'indiquer que vous avez répondu correctement
    e3_roomResolved = true;
    let e3RoomResolved = sessionStorage.setItem("Enigme3RoomResolved",e3_roomResolved);
    //Permet de retirer l'action de son bloc d'action et de le cacher
    AddRemoveClass('ba3GR_answerEnigmeRoom',false,'baE3_ghostAnswer');
    EditIdDisplay('ba3GR_answerEnigmeRoom','none');
  }
  if(e3_characterResolved == true && e3_roomResolved == true)
  {
    e3_wasResolved = true;
  }
  HidePossibilityOfAnswerForEnigme3()
}

function HidePossibilityOfAnswerForEnigme3()
{
  if (e3_wasResolved == true)
  {
    AddRemoveClass("ba3G_answerEnigme", false, "baE3_ghost");
    EditIdDisplay("ba3G_answerEnigme", "none");
  }
  if (e3_wasResolved == true)
  {
    ModalTextPage("Vous vous déplacez vers la porte....","bedroom.html")
    //ChangePage("bedroom.html",6000);
    SetPageLocalisation('bedroom');
  }
}

/* ########################################################################## */

/*
  -----------
  ## ROOM  ## 
  -----------
*/

// ACTION = RETOURNER A LA PIECE PRINCIPAL 
function ActionGoToRoomToRoom()
{
  //Changement d'image
  ActionGoTo('library/library.jpg','baE3_room','baE3_mainRoom');
}
// ACTION = AFFICHER DU TEXTE POUR LES ETAGERES AVEC TIROIRS
function DisplayTextForShelf2(shelf)
{
  if (shelf == "shelfA")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont un livre de Victor Hugo intitulé \'La légende des siècles\'.</p>');
  }
  else if (shelf == "shelfC")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont un livre de Henry Verne.</p>');
  }
  else if (shelf == "shelfD")
  {
    ModalText('<p>Une étagère avec diverses collections de livre dont un livre de Guy de Maupassant.</p>');
  }
  else if (shelf == "shelfE")
  {
    ModalText('<p>Une étagère avec diverses collections de livre de Jules Verne.</p>');
  }
  else if (shelf == "shelfF")
  {
    ModalText('<p>Une étagère avec diverses collections de livre de William Shakespeare.</p>');
  }
  else
  {
    ModalText('<p>Une étagère avec divers collections de livres.</p><p>Vous pouvez voir également un post-il où il est écrit : "Code : - - 0 -"</p>');
  }
}
// ACTION = INTERACTION AVEC LA TABLE 

// ACTION = INTERACTION AVEC UNE CHAISE (a & b)