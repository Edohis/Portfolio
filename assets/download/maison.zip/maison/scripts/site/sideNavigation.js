/* ########################################################################## */
/*
  << OPEN/CLOSE SIDE NAVIGATION >>
*/
/* ########################################################################## */

/* ########################################################################## */

// FUNCTION : OPEN NAVIGATION WHEN CLOSED
function OpenNavigation() {
  document.getElementById("sideNavigation").style.display = "block";
  document.getElementById("sideNavigationContent").style.width = "40vh";
  document.getElementById("sideNavigationContent").style.display = "block";
  let sideNavOpen = true;
  sessionStorage.setItem("checkSideNavigation",sideNavOpen);
  //let getRoom = sessionStorage.getItem("homeRoom") || "none";
  //let getPageResult = sessionStorage.getItem("resultGamePage")  || "none";
  //if(getPageResult == "true" || getRoom == "outsideEnd") 
  //{
    stopTimer();
  //}
};

// FUNCTION : CLOSE NAVIGATION WHEN OPEN 
function CloseNavigation() {
  document.getElementById("sideNavigation").style.display = "none";
  document.getElementById("sideNavigationContent").style.width = "0vh";
  document.getElementById("sideNavigationContent").style.display = "none";
  let sideNavOpen = false;
  sessionStorage.setItem("checkSideNavigation",sideNavOpen);
  //let getRoom = sessionStorage.getItem("homeRoom") || "none";
  //let getPageResult = sessionStorage.getItem("resultGamePage")  || "none";
  //if(getPageResult == "true" || getRoom == "outsideEnd") 
  //{
    lauchTimer();
  //}
};