/* ########################################################################## */
/*
  << LOGIN AND LOGOUT >>
*/
/* ########################################################################## */

/* ########################################################################## */

// FUNCTION = DISPLAY MODAL LOGIN 
function DisplayModalLogin()
{
  let modal = document.getElementById("modalLoginLogout");
  let textCo = document.getElementById("compte");
  let statutCo = sessionStorage.getItem("connexion");
  let gameLaucher = sessionStorage.getItem("setGameLaucher")
  if(gameLaucher == "true")
  {
    if (statutCo)
    {
      if (statutCo == "estConnecter")
      {
        modal.style.display = "none";
        textCo.innerHTML = "Deconnexion";
        textCo.href = "index.html"
      }
      else if (statutCo == "estDeconnecter")
      {
        modal.style.display = "block";
        textCo.innerHTML = "Connexion/Inscription";
      }
    }
    else
    {
      modal.style.display = "block";
      textCo.innerHTML = "Connexion/Inscription";
    }
  }
  else
  {
    ModalText("REDIRECTION EN COURT : Vous n'êtes pas passé par la page d'index !");
    gameLaucher = true
    gameLaucher = sessionStorage.setItem("setGameLaucher",gameLaucher)
    ChangePage("index.html");
  }
}

/* ########################################################################## */

/* -------------------------------------------------------------------------- */
/* 
  ## PROVISOIRE ## 
*/
/* -------------------------------------------------------------------------- */

// FUNCTION = START GAME IF NOT LOGIN 
function StartGame()
{
  let gameLaucher = sessionStorage.getItem("setGameLaucher")
  let modal = document.getElementById("modalLoginLogout");
  let textCo = document.getElementById("compte");
    
  if(gameLaucher == "true")
  {
    modal.style.display = "none";
    textCo.innerHTML = "Deconnexion";
    sessionStorage.setItem("connexion", "estConnecter");
  }
  DisplayModalLogin();
}

// FUNCTION = CLOSE GAME IF LOGIN
function CloseGame()
{
  sessionStorage.setItem("connexion", "estDeconnecter");
  DisplayModalLogin();
}