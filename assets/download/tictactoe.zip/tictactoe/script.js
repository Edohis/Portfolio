//DECLARATION DE VARIABLES UTILISER DANS LA PLUPART DES FONCTIONS
let partieEnCourt = false; //permet de savoir si une partie est en court 
let partieDejaJouer = false; //permet d'afficher le bouton "recommencer" & "accueil/quitter"
let joueurActive = "X"; 
let tour = 0; //utilise pour le match nul
let progressionPartie = ["", "", "", "", "", "", "", "", ""]; //stock les divers tours;
const comboGagnant = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
  ];
  
function lancerPartie()
{
  //Initialisation de la partie
  partieEnCourt = true;
  partieDejaJouer = true;
  joueurActive = "X";
  tour = 0;
  progressionPartie = ["", "", "", "", "", "", "", "", ""];
  
  //Permet de modifier l'affichage de démarrage
  const boutonContainerStart = document.getElementById("btnContainerStart");
  boutonContainerStart.style.display = "none";
  const boutonStart = document.getElementById("btnStart");
  boutonStart.style.display = "none";
  
  //Permet de modifier l'affichage de la partie
  const containerDuJeu = document.getElementById("containerGame");
  containerDuJeu.style.display = "block";
  
  //Permet de créer le onclick;
  document.querySelectorAll('.cell').forEach(cell => cell.addEventListener('click',choixCase));
  //Permet d'afficher un message
  message("tour", joueurActive);
  //Permet de s'assurer quand une partie commence que les cases soient vides
  videCase();
}


function message(type, joueurActive)
{
  //ne sert à rien => const info = document.getElementById("info");
  switch(type)
  {
    case "tour":
      info.innerHTML = "C'est au tour du joueur " + joueurActive + " de jouer !";
      break;
    case "victoire":
      info.innerHTML = "Le joueur " + joueurActive + " a gagné la partie !";
      break; 
    case "nul":
      info.innerHTML = "La partie s'est terminer par un match nul ! Aucun gagnant !";
      break;
    default: 
      alert("ERREUR !");
  }
}

function changementJoueur()
{
  //Permet de changer entre les deux joueurs et de l'indiquer
  joueurActive = joueurActive === "X" ? "O" : "X"; //si joueurActive == "X" : "O", sinon joueurActive == "0" : "X"
  message("tour", joueurActive);
}

function choixCase(valeur)
{
  //Permet la sélectionne de la case
  let caseCliquer = valeur.target;

  effectuerTour(caseCliquer);  //valeur
  if(partieEnCourt == true)
  {
    verificationFinDePartie(caseCliquer);
  }
  else
  {
    alert('la partie est terminer, vous devez recommencer une nouvelle partie !');
    //alert("end ; progression - JOUEUR = " + progressionPartie[caseCliquer.id] + " & PLATEAU = " + progressionPartie);
  }
}

function effectuerTour(caseCliquer) //valeur
{
  if(partieEnCourt == true)
  {
    //Permet de vérifier la disponibilité de la case
    //alert("progression - JOUEUR = " + progressionPartie[caseCliquer.id] + " & PLATEAU = " + progressionPartie);
    if(caseCliquer.innerHTML != "")
    {
      alert("Impossible ! Case déja prise ! Sélectionnez une autre case, qui doit être vide !");
      //alert("CDP ; progression - JOUEUR = " + progressionPartie[caseCliquer.id] + " & PLATEAU = " + progressionPartie);
      choixcase(caseCliquer.id); //valeur
    }
    else if(caseCliquer.innerHTML == "")
    {
      caseCliquer.innerHTML = joueurActive;
      progressionPartie[caseCliquer.id] = joueurActive;
      //alert("progression 2 - JOUEUR = " + progressionPartie[caseCliquer.id] + " & PLATEAU = " + progressionPartie);
    }
    else //Permet de savoir s'il y a une erreur 
    {
      alert("ERREUR : effectuerTour()")
      partieEnCourt = false;
      //alert("progression - JOUEUR = " + progressionPartie[caseCliquer.id] + " & PLATEAU = " + progressionPartie);
    }
  }
  else if(partieEnCourt == false)
  {
    alert("Impossible ! Aucune partie en court");
    //alert("Imp ; progression - JOUEUR = " + progressionPartie[caseCliquer.id] + " & PLATEAU = " + progressionPartie);
  }
  else
  {
    alert("ERREUR : effectuerTour()")
    //alert("Err ; progression - JOUEUR = " + progressionPartie[caseCliquer.id] + " & PLATEAU = " + progressionPartie);
  }
}

function verificationFinDePartie(caseCliquer)
{
  //Permet de vérifier si le tour actuel permet de mettre fin à la partie
  let tourGagnant = false;
  //Cherche à savoir si un joueur a aligné trois "X" ou "O";
  for(let i = 0; i <= 7; i++)
  {
    const checkCombo = comboGagnant[i];
    let case1 = progressionPartie[checkCombo[0]];
    let case2 = progressionPartie[checkCombo[1]];
    let case3 = progressionPartie[checkCombo[2]];
    if (case1 === "" || case2 === "" || case3 === "")
    {
      continue;
    }
    if(case1 == case2 && case2 == case3)
    {
      tourGagnant = true;
      break; //permet de quitter la boucle;
    }
  }
  //Permet de mettre fin à la partie, d'afficher le message de victoire ou nul et de proposer de recommencer ou de quitter
  tour++
  if(tourGagnant || tour == 9)
  {
    partieEnCourt = false;    
    tourGagnant = tourGagnant == true ? message("victoire",joueurActive) : message("nul");
    partie();
    return;
  }
  //Permet de changer de joueur tant que la partie continue
  changementJoueur();
}

  //Fonction qui permet d'afficher les boutons "recommencer" & "accueil/quitter"
function partie() 
{
  let modal = document.getElementById("log");
  modal.style.display = "flex";
}

  //Fonction pour le bouton "recommencer"
function recommencerPartie()
{
  //Modifie l'affichage
  let blocBoutonPartie = document.getElementById("log");
  blocBoutonPartie.style.display = "none";
  
  //Lance la partie
  lancerPartie();
}

  //Fonction pour le bouton "accueil/quitter"
function fermerPartie()
{
  //Permet de modifier l'affichage 
  const containerDuJeu = document.getElementById("containerGame");
  containerDuJeu.style.display = "none";
  let blocBoutonPartie = document.getElementById("log");
  blocBoutonPartie.style.display = "none";
  
  const btnContainerStart = document.getElementById("btnContainerStart");
  btnContainerStart.style.display = "flex";
  const btnStart = document.getElementById("btnStart");
  btnStart.style.display = "block";
}

  //Fonction qui permet de s'assurer que les cases soient bien vide pour une partie;
function videCase()
{
  let list = document.getElementsByClassName("cell");
  for (let i = 0, len = list.length; i < len; i++)
  {
    list[i].innerHTML = "";
  }
}